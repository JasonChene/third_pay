package com.cn.demo;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class Test {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String FormatBizQueryParaMap(Map<String, String> paraMap,
			boolean urlencode) throws Exception {
		String buff = "";
		try {
			List infoIds = new ArrayList(paraMap.entrySet());

			Collections.sort(infoIds,
					new Comparator<Map.Entry<String, String>>() {
						public int compare(Map.Entry<String, String> o1,
								Map.Entry<String, String> o2) {
							return ((String) o1.getKey()).toString().compareTo(
									(String) o2.getKey());
						}
					});
			for (int i = 0; i < infoIds.size(); i++) {
				Map.Entry item = (Map.Entry) infoIds.get(i);

				if (item.getKey() != "") {
					String key = String.valueOf(item.getKey());
					String val = String.valueOf(item.getValue());
					if (urlencode) {
						val = URLEncoder.encode(val, "utf-8");
					}
					if ("".equals(val)) {
						continue;
					}
					buff = buff + key + "=" + val + "&";
					// buff = buff + key.toLowerCase() + "=" + val + "&";
				}
			}
			if (!buff.isEmpty())
				buff = buff.substring(0, buff.length() - 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return buff;
	}

	@SuppressWarnings("unchecked")
	public static JSONObject sign(JSONObject req, String signKey) {
		try {
			if ("".equals(signKey) || null == signKey) {
				signKey = "";
			}
			Map<String, String> map = new HashMap<String, String>();
			map = JSON.toJavaObject(req, Map.class);
			String noSignStr = FormatBizQueryParaMap(map, false);// 未签名的字符串
			String sign = MD5s.Sign(noSignStr, signKey);// 签名
			req.put("sign", sign);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return req;
	}

	public static String CreateNoncestr(int length) {
		String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		String res = "";
		for (int i = 0; i < length; i++) {
			Random rd = new Random();
			res = res + chars.charAt(rd.nextInt(chars.length() - 1));
		}
		return res;
	}

	public static void main(String[] args) throws UnsupportedEncodingException {

		String AppKey = "1234567890";//注：这个需要换成实际的商户密钥
		String url = "https://api.yingyupay.com:31006/yypay";
		JSONObject reqData = new JSONObject();
		reqData.put("messageid", "200001");
		reqData.put("out_trade_no", "123456abce");  //商户方的流水号，在同个商户号下必须唯一
		reqData.put("back_notify_url", "http://www.xxxx.com/notify.action");   //商户的回调地址
		reqData.put("branch_id", "000001");   //注：这个需要换成实际的商户号
		reqData.put("prod_name", "测试支付");
		reqData.put("prod_desc", "测试支付描述");
		reqData.put("pay_type", "10");
		reqData.put("total_fee", 10);
		reqData.put("nonce_str", CreateNoncestr(32));
		reqData = sign(reqData, AppKey);
		System.out.println("发送报文" + reqData.toJSONString());
		byte[] resByte = HttpsUtil.httpsPost(url, reqData.toJSONString());
		if (null == resByte) {
			System.out.println("返回报文为空");
		} else {
			System.out.println("返回数据:" + new String(resByte, "UTF-8"));
		}
	}
}
