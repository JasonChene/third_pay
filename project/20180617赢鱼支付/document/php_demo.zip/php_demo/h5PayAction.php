<html>
<body>
<?php

require_once "utils.php";

function h5PayHandle() {

    $appKey = $_POST['key'];

    $url = "https://api.yingyupay.com:31006/yypay";
    $reqData = array(
        'messageid'         => '200004',
        'out_trade_no'      => $_POST['out_trade_no'],
        'back_notify_url'   => $_POST['back_notify_url'],
        'front_notify_url'   => $_POST['front_notify_url'],
        'branch_id'         => $_POST['branch_id'],
        'prod_name'         => '测试支付',
        'prod_desc'         => '测试支付描述',
        'pay_type'          => $_POST['pay_type'],
        'total_fee'         => $_POST['total_fee'],
        'nonce_str'         => createNoncestr(32)
    );

    $reqData = sign($reqData, $appKey);
    $result = httpPost($url, $reqData);
    $resultJson=json_decode($result);
    if ($resultJson->resultCode == '00' && $resultJson->resCode == '00') {

        $resultToSign = array();

        foreach ($resultJson as $key => $value) {
            if ($key != 'sign') {
                $resultToSign[$key] = $value;
            }
        }

        $str = formatBizQueryParaMap($resultToSign);
        $resultSign = strtoupper(md5($str."&key=".$appKey));

        if ($resultSign != $resultJson->sign) {
            echo '签名验证失败';
        } else {
            header("Location:".$resultJson->payUrl);
            
        }
    } else {
        echo $resultJson->resDesc;
    }

}

h5PayHandle();



?>
</body>
</html>