<html>
<body>
<?php

require_once "utils.php";

function bankPayHandle() {

    $appKey = $_POST['key'];

    $url = "https://api.yingyupay.com:31006/yypay";
    $reqData = array(
        'messageid'         => '200002',
        'out_trade_no'      => $_POST['out_trade_no'],
        'back_notify_url'   => $_POST['back_notify_url'],
        'front_notify_url'   => $_POST['front_notify_url'],
        'branch_id'         => $_POST['branch_id'],
        'prod_name'         => '测试支付',
        'prod_desc'         => '测试支付描述',
        'pay_type'          => '30',
        'bank_code'          => $_POST['bank_code'],
        'bank_flag'          => $_POST['bank_flag'],
        'total_fee'         => $_POST['total_fee'],
        'nonce_str'         => createNoncestr(32)
    );

    $reqData = sign($reqData, $appKey);
    $result = httpPost($url, $reqData);
    //$resultJson=json_decode($result);
    
    echo $result;
    
    

//    var_dump($result);exit;
}

bankPayHandle();

function showEWM($payUrl) {
    header("location:WxpayAPI_php_v3/example/qrcode.php?data=".$payUrl);
}

?>
</body>
</html>