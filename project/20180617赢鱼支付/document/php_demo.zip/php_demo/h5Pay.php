
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>手机H5支付DEMO</title>
</head>
<body>
	<form action="h5PayAction.php" method="post">
        <div style="margin-left:2%;color:#f00">请在手机浏览器上测试此页面，注意不同的支付方式浏览器支持会有限制，比如微信WAP必须在微信浏览器打开</div><br/>
        <div style="margin-left:2%;">商户号（branch_id）：</div>
        <input type="text" style="width:96%;height:30px;margin-left:2%;" name="branch_id" value=""/><br /><br />
        <div style="margin-left:2%;">商户流水号（out_trade_no）：</div>
        <input type="text" style="width:96%;height:30px;margin-left:2%;" name="out_trade_no" /><br /><br />
        <div style="margin-left:2%;">后台回调地址（back_notify_url）：</div>
        <input type="text" style="width:96%;height:30px;margin-left:2%;" name="back_notify_url" value="http://xx.xx.xx/php_demo/notify.php"/><br /><br />
				<div style="margin-left:2%;">前台回调地址（front_notify_url）：</div>
        <input type="text" style="width:96%;height:30px;margin-left:2%;" name="front_notify_url" value="http://xx.xx.xx/php_demo/pageNotify.php"/><br /><br />
				<div style="margin-left:2%;">商户密钥（key）：</div>
				<input type="text" style="width:96%;height:30px;margin-left:2%;" name="key" value=""/><br /><br />
        <div style="margin-left:2%;">支付金额（total_fee）：</div>
        <input type="text" style="width:96%;height:30px;margin-left:2%;" name="total_fee" value="1"/><br /><br />
        <div style="margin-left:2%;">支付类型（pay_type）：
        <select name="pay_type">
            <option value="61">微信wap</option>
            <option value="62">支付宝wap</option>
            <option value="63">QQ钱包wap</option>
            <option value="64">京东wap</option>
            <option value="65">银联快捷wap</option>
        </select>
        </div>
        <div align="center">
			<input type="submit" value="支付" style="width:210px; height:50px; border-radius: 15px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;" type="submit" />
		</div>
	</form>
</body>
</html>
