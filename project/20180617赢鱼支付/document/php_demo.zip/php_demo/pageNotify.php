
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>网银支付成功</title>
</head>
<body>
	<form action="qrcodePayAction.php" method="post">
        <div style="margin-left:2%;color:#f00">订单支付成功！</div><br/>
        <div tyle="margin-left:2%;color:#f00">这个页面由接入方自己弄，比如加个按钮“返回查看我的订单”</div>
	</form>
</body>
</html>
