﻿package com.pay;



public class pay_config {
	
	
	// APPID
	public static String appid="10000001";
	
	// APPKEY
	public static String key="a006e912ceb3eb4d9682d9aa6b47b291";
	
    //支付地址
	public static String  apiurl="http://pay.caoliupay.com/Pay.html";
	
    //异步通知地址
	public static String  	notify_url="http://xxxx/notify_url.jsp";

}
