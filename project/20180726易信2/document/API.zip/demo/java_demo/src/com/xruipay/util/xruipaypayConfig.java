package com.guangjupaypay.util;

import java.util.ResourceBundle;

public class guangjupaypayConfig {

	private static Object lock              = new Object();
	private static guangjupaypayConfig config     = null;
	private static ResourceBundle rb        = null;
	private static final String CONFIG_FILE = "com.leshouka.common.ParterInfo";
	
	private guangjupaypayConfig() {
		rb = ResourceBundle.getBundle(CONFIG_FILE);
	}
	
	public static guangjupaypayConfig getInstance() {
		synchronized(lock) {
			if(null == config) {
				config = new guangjupaypayConfig();
			}
		}
		return (config);
	}
	
	public String getValue(String key) {
		return (rb.getString(key));
	}
}
