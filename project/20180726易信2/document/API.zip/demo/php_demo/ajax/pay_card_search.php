<?php
error_reporting(0);
header('Content-Type:text/html;charset=GB2312');
include_once("../config/pay_config.php");
include_once("../lib/class.guangjupay.php");
$guangjupay = new ekapay();
$guangjupay->parter 		= $obao_merchant_id;		//商家Id
$guangjupay->key 			= $obao_merchant_key;	//商家密钥

$result	= $guangjupay->search($_POST['order_id']);

$data = '{"success": "'.$result.'","message": "'. $guangjupay->message .'"}';
die($data);
?>