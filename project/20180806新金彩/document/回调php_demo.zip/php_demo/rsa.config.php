<?php
$rsa_config = array(
    //公钥
    'public_key' => '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCs9mGo+/7kn12b98xRrMFxwvmuDvxkjPiuGd8ly4YR887WdAYw1hKCs9vCNNGC93PMzvyI7G+B9ZT/KDPdjY1aavAZeNpIz1emn+XrU0miaLYl6VU/cPtKgAMHO3DA1LTjK6p7BZc2ZtoGNFSAjXujcXNsuiV4kQlzJeJ4x2QwIwIDAQAB
-----END PUBLIC KEY-----',
    //私钥 把你的私钥粘贴到第9行
    'private_key' => '-----BEGIN RSA PRIVATE KEY-----

-----END RSA PRIVATE KEY-----'
);

