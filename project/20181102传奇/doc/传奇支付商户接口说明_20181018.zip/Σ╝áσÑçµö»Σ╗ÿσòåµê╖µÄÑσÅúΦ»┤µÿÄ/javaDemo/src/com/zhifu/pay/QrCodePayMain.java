package com.zhifu.pay;

public class QrCodePayMain {

	/**
	 * 商户编号
	 */
	public static String mercId = "200000090000100";
	
	/**
	 * 提交URL
	 */
	public static String url="http://47.74.36.178/codePay";
	
	

}
