package com.zhifu.pay.dto;

import java.io.Serializable;


public interface IResponseDTO extends Serializable{
	
//	public String getRespCode();
//	
	public void setRespCode(String respCode);
//	
//	public String getRespMsg() ;
//
	public void setRespMsg(String respMsg) ;
//	
//	public boolean isSuccess();
	
}
