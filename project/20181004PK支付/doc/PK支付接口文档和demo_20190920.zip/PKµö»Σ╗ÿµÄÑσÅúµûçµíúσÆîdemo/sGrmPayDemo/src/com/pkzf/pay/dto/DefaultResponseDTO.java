package com.pkzf.pay.dto;


/**
 * 
 * @author hunter
 *
 */
public class DefaultResponseDTO extends AbstractResponseDTO {

    /** serialVersionUID */
    private static final long serialVersionUID = -1476554877426504255L;

    
	
}
