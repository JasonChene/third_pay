package com.pkzf.pay;

public class QrCodePayMain {

	/**
	 * 商户编号
	 */
	public static String mercId = "100000010000002";
	
	/**
	 * 提交URL
	 */
	public static String url="http://api.3030ka.com/grmApp";
	
	

}
