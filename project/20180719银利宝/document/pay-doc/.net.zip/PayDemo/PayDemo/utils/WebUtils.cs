﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PayDemo.utils
{
    public class WebUtils
    {
        public static string GetBasePath()
        {
            return  System.IO.Directory.GetParent(System.Environment.CurrentDirectory).Parent.FullName;
        }

        public static string GetAppRoot()
        {
            return System.AppDomain.CurrentDomain.BaseDirectory.ToString();
        }
    }
}