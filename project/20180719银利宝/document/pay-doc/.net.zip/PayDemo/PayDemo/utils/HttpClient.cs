﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace PayDemo.utils
{
    public class HttpClient
    {
        public static string Post(string url, IDictionary<string, string> parameters)
        {
            //创建一个HTTP请求  
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            //Post请求方式  
            request.Method = "POST";
            //内容类型
            request.ContentType = "application/json;charset=UTF-8";
            
            string jsonString = ToJsonString(parameters);
            Console.Write(jsonString);

            byte[] payload;
            //将Json字符串转化为字节  
            payload = Encoding.UTF8.GetBytes(jsonString);
            //设置请求的ContentLength   
            request.ContentLength = payload.Length;
            //发送请求，获得请求流 

            Stream writer;
            try
            {
                writer = request.GetRequestStream();//获取用于写入请求数据的Stream对象
            }
            catch (Exception)
            {
                writer = null;
                Console.Write("连接服务器失败!");
            }
            //将请求参数写入流
            writer.Write(payload, 0, payload.Length);
            writer.Close();//关闭请求流

            HttpWebResponse response;
            try
            {
                //获得响应流
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException ex)
            {
                response = ex.Response as HttpWebResponse;
            }

            Stream s = response.GetResponseStream();

            StreamReader sr = new StreamReader(s);
            string postContent = sr.ReadToEnd();
            sr.Close();


            return postContent;//返回Json数据
        }

        public static string ToJsonString(IDictionary<string, string> parameters)
        {
            StringBuilder sb = new StringBuilder("{");

            foreach (var item in parameters)
            {
                sb.Append("\"").Append(item.Key).Append("\":\"").Append(item.Value).Append("\",");
            }
            sb.Remove(sb.Length - 1, 1);
            sb.Append("}");
            return sb.ToString();
        }
    }
}