﻿using PayDemo.config;
using PayDemo.utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace PayDemo
{
    public partial class Pay : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string payUrl = unifiedorder();
            Response.StatusCode = 301;
            Response.Status = "301 Moved Permanently";
            Response.AppendHeader("Location", payUrl);
            Response.AppendHeader("Cache-Control", "no-cache");  //这里很重要的一个设置， no-cache 表示不做本地缓存
            Response.End();
        }

        private static string unifiedorder()
        {

            DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long timestamp = (long)(DateTime.Now - startTime).TotalSeconds;
            string nonce = "NONCE" + timestamp ;

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("mch_id", PayConfig.MCH_ID);
            parameters.Add("trade_type", "ALIH5");
            parameters.Add("nonce", nonce);
            parameters.Add("timestamp", timestamp.ToString());
            parameters.Add("subject", "这是标题");
            parameters.Add("detail", "这是详情");
            parameters.Add("out_trade_no", "TEST" + timestamp.ToString());
            parameters.Add("total_fee", "3000");
            parameters.Add("spbill_create_ip", "225.225.225.255");
            parameters.Add("notify_url", "http://domain/pay/test/notify_url");
            parameters.Add("return_url", "http://domain/pay/test/return_url");
            parameters.Add("sign", Signature.Md5Sign(parameters, PayConfig.API_KEY));

            string content = HttpClient.Post(PayConfig.PAY_URL, parameters);
            Dictionary<string, object> result = fastJSON.JSON.ToObject<Dictionary<string, object>>(content);
            string publicKeyPem = WebUtils.GetAppRoot() + "/cert/rsa_public_key.pem";
            if (!Signature.RsaVerifySign(result, publicKeyPem, Signature.DEFAULT_CHARSET))
            {
                throw new Exception("签名校验失败");
            }

            object payUrl = "";
            result.TryGetValue("pay_url", out payUrl);

            
            return payUrl.ToString();

        }
    }
}