﻿using PayDemo.utils;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PayDemo
{
    public partial class Notify : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            NameValueCollection form = Request.Form;
            IDictionary<string, string> parameters = new Dictionary<string, string>();
            foreach(String key in form) {
                string value = form.GetValues(key)[0].ToString();
                parameters.Add(key, value);
            }
            if(parameters.Count == 0)
            {
                throw new Exception("参数错误");
            }
            string publicKeyPem = WebUtils.GetAppRoot() + "/cert/rsa_public_key.pem";
            if (!Signature.RsaVerifySign(parameters, publicKeyPem, Signature.DEFAULT_CHARSET))
            {
                throw new Exception("签名校验失败");
            }

            string resultCode = Request.Form["result_code"];
            if ("SUCCESS".Equals(resultCode))
            {
                // TODO 进行成功业务处理

                Response.AppendHeader("Content-Type", "text/plain");
                Response.Write("SUCCESS");
                Response.End();
            }


           
        }
    }
}