﻿using PayDemo.config;
using PayDemo.utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PayDemo
{
    public partial class Query : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String orderNo = "GO20180504112044006450"; // 商户下单提交的单号
            String platformTradeNo = "TO20180504112049128888"; // 支付平台生成的流水号

            DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long timestamp = (long)(DateTime.Now - startTime).TotalSeconds;
            string nonce = "NONCE" + timestamp;

            IDictionary<string, string> parameters = new Dictionary<string, string>();
            parameters.Add("mch_id", PayConfig.MCH_ID);
            parameters.Add("out_trade_no", orderNo);
            parameters.Add("nonce", nonce);
            parameters.Add("platform_trade_no", platformTradeNo);
            parameters.Add("sign", Signature.Md5Sign(parameters, PayConfig.API_KEY));

            string content = HttpClient.Post( PayConfig.QUERY_URL, parameters);
            if ("".Equals(content))
            {
                throw new Exception("查询失败");
            }
            Dictionary<string, object> result = fastJSON.JSON.ToObject<Dictionary<string, object>>(content);
            string publicKeyPem = WebUtils.GetAppRoot() + "/cert/rsa_public_key.pem";
            if (!Signature.RsaVerifySign(result, publicKeyPem, Signature.DEFAULT_CHARSET))
            {
                throw new Exception("签名校验失败");
            }
            object resultCode = null;
            result.TryGetValue("result_code", out resultCode);
            if ("SUCCESS".Equals(resultCode))
            {
                // 支付成功
            }

            foreach(var item in result){
                Console.WriteLine(item.Key + ":" + item.Value);
            }
        }
    }
}