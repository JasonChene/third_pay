﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PayDemo.config
{
    public class PayConfig
    {
        public static string MCH_ID = "1525399982"; // 商户号

        public static string API_KEY = "34747aa775086242d1ec9bd9c7c74cf5";  // 接口秘钥

        public static string API_BAEE_URI = "http://localhost";  // 接口域名

        public static string PAY_URL = API_BAEE_URI + "/pay/unifiedorder"; // 统一下单接口地址

        public static string QUERY_URL = API_BAEE_URI + "/pay/query"; // 支付结果查询接口地址
    }
}