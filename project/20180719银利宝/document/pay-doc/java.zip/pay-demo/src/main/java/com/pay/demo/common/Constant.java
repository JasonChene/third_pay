package com.pay.demo.common;

public class Constant {
	
	public static final String RSA_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgPPllyqG5VUWM3szLU6yiqcBbMnFS3QcqaErEDXjpijqxfwsIDuqywwwhGgkv6EtOLQWMRYyqzMaQY/Xa5qgEIM+ORuiwnJG8Ikj4W8txlj7L5Ublihk+KXqm/O1NuMebgBBaEmjMUueP/AT+zVsWLj05QjkRaIa9n+B42nHMEVi3F05SJeNmhEBaE+NBVGQOgYwMFQ99bOhgJLkeJaF9MAVNaLhmCG/dYSQqRfylTR7GMzV8G40mW4aTe0prgG8pbUzzMd8ZuyXusABiON+wIen+INP9TwaQs5B58k0z3xZ3E8g+EMjSIYkBsenP9GQS4UuMr8t8NeGgi2+h0gb6wIDAQAB";

	/**
	 * 商户ID
	 */
	public static String MCH_ID = "1525399982";
	
	/**
	 * 接口支付秘钥
	 */
	public static String API_KEY = "34747aa775086242d1ec9bd9c7c74cf5";

	/**
	 * 接口地址
	 */
	public static String API_BASE_URI = "https://api.tonghejinxian.com";
	
	/**
	 * 下单地址
	 */
	public static String PAY_URL =  API_BASE_URI + "/pay/unifiedorder";
	
	/**
	 * 查询地址
	 */
	public static String QUERY_URL =  API_BASE_URI + "/pay/query";
}
