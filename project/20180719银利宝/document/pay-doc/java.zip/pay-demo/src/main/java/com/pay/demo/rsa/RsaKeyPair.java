package com.pay.demo.rsa;


public class RsaKeyPair {
	
	/**
	 * 秘钥
	 */
	private String privateKey;
	
	/**
	 * 公钥
	 */
	private String publicKey;

	public RsaKeyPair() { }
	
	/**
	 * 构造方法
	 * @param privateKey
	 * @param publicKey
	 */
	public RsaKeyPair(String privateKey, String publicKey){
		this.privateKey = privateKey;
		this.publicKey = publicKey;
	}
	
	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	
	
	
}
