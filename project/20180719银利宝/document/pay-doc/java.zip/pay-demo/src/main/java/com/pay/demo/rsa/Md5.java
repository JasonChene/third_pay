package com.pay.demo.rsa;

import org.springframework.util.DigestUtils;

public class Md5 {

	/** Md5 加密
	 * 
	 * @param content
	 * @return
	 */
	public static String encrypt(String content) {
		return DigestUtils.md5DigestAsHex(content.getBytes());
	}
}
