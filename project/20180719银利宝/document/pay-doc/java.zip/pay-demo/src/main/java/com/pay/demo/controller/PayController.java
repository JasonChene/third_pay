package com.pay.demo.controller;

import java.io.IOException;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.pay.demo.common.Constant;
import com.pay.demo.http.SimpleHttpClient;
import com.pay.demo.utils.PayUtils;
import com.pay.demo.utils.RequestUtils;

@RestController
public class PayController {
	
	
	
	@RequestMapping("/unifiedorder")
	public void unifiedorder(){
		SortedMap<String, String> map = new TreeMap<String,String>();
		map.put("trade_type", "ALIH5");
		map.put("mch_id", Constant.MCH_ID);
		map.put("nonce", PayUtils.generateNonce());
		map.put("timestamp", System.currentTimeMillis() / 1000 + "");
		/*map.put("sign_type", "HMAC-SHA256");*/
		map.put("subject", "购买眼镜");
		map.put("detail", "太阳眼镜");
		map.put("out_trade_no", PayUtils.generateNonce());
		map.put("total_fee", "3000");
		map.put("spbill_create_ip", "255.255.255.255");
		map.put("timeout", "30");
		map.put("notify_url", "http://localhost:8080/notify");
		map.put("sign", PayUtils.createSign(map, Constant.API_KEY));
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(map);
		String content = SimpleHttpClient.post(Constant.PAY_URL, jsonObject);
		System.out.println(content);
		SortedMap<String, String> response = PayUtils.toSortedMap(content);
		
		if(PayUtils.verifySign(response, Constant.RSA_PUBLIC_KEY)){
			System.out.println(response.get("pay_url"));
		}
		
	}
	
	@RequestMapping("/query")
	public void query(){
		
		String platFormTradeNo = "TO20180604135219160597";
		String orderNo = "20180604135486645";
		SortedMap<String, String> map = new TreeMap<String,String>();
		map.put("mch_id", Constant.MCH_ID);
		map.put("nonce", PayUtils.generateNonce());
		
		map.put("out_trade_no", orderNo);
		// map.put("platform_trade_no", platFormTradeNo);
		
		map.put("sign", PayUtils.createSign(map, Constant.API_KEY));
	
		JSONObject jsonObject = (JSONObject) JSONObject.toJSON(map);
		String content = SimpleHttpClient.post(Constant.QUERY_URL, jsonObject);
		SortedMap<String, String> response = PayUtils.toSortedMap(content);
		if(PayUtils.verifySign(response, Constant.RSA_PUBLIC_KEY)){
			System.out.println(response.get("result_code"));
		}
		
	}
	
	/**
	 * 异步通知
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/notify", method=RequestMethod.POST)
	public void testNotifyUrl(HttpServletRequest request,  HttpServletResponse response) throws IOException {
		SortedMap<String, String> parameters = RequestUtils.getFormData(request);
		if(!PayUtils.verifySign(parameters, Constant.RSA_PUBLIC_KEY)){
			System.out.println("签名失败");
			return ;
		}
		
		if("SUCCESS".equalsIgnoreCase(parameters.get("result_code"))){
			// TODO 处理
			response.getWriter().print("SUCCESS");
		}


	}
}
