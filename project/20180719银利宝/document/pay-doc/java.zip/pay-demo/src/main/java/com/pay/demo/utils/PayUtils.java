package com.pay.demo.utils;



import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.UUID;

import com.alibaba.fastjson.JSONObject;
import com.pay.demo.rsa.Md5;
import com.pay.demo.rsa.RSA;

public class PayUtils {

	
	/**
	 * Object To SortedMap
	 * @param object
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static SortedMap<String, String> toSortedMap(String content){
		JSONObject jsonObject = JSONObject.parseObject(content);
		
		SortedMap<String, String> map = new TreeMap<String, String>();
		for (Map.Entry<String, Object> entry : jsonObject.entrySet()) {
			String key = entry.getKey();
			Object obj = entry.getValue();
			String value = String.valueOf(obj);
			if(obj == null) {
				value = null;
			}
			map.put(key, value);
			System.out.println(entry.getKey() + ":" + entry.getValue());
        }
		return map;
	}
	
	
	/**
	 *  生成sign
	 * @param parameters
	 * @param apiKey
	 * @return
	 */
	public static String createSign(SortedMap<String, String> parameters, String apiKey){
		StringBuffer sb = new StringBuffer();
		for (Map.Entry<String, String> entry : parameters.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			if (!"sign".equalsIgnoreCase(key) && !"key".equalsIgnoreCase(key)
					&& value != null && !"".equals(value)) {
				sb.append(key + "=" + value + "&");
			}
		}
		String plaintext = sb.toString() + "key=" + apiKey;
		String sign = Md5.encrypt(plaintext);
		return sign;
	}
	
	/**
	 * 签名校验
	 * @param map
	 * @return
	 */
	public static boolean checkSign(SortedMap<String, String> parameters, String apiKey){
		String sign = String.valueOf(parameters.get("sign"));
		StringBuffer sb = new StringBuffer();
		for(Entry<String, String> entry : parameters.entrySet()){
			String key = entry.getKey();
			String value = entry.getValue();
			if (!"sign".equalsIgnoreCase(key) && !"key".equalsIgnoreCase(key) 
					&& value != null && !"".equals(value)) {
				sb.append(key + "=" + value + "&");
			}
		}
		String plaintext = sb.toString() + "key=" + apiKey;
		String validateSign = Md5.encrypt(plaintext);
		return validateSign.equalsIgnoreCase(sign);
	}

	
	/**
	 * 随机字符串
	 * @return
	 */
	public static String generateNonce() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	
	/**
	 * 创建RSA 签名
	 * @param map
	 * @param privateKey
	 * @return
	 */
	public static String createRsaSign(SortedMap<String, String> map, String privateKey) {
		StringBuffer sb = new StringBuffer();
		for(Entry<String, String> entry : map.entrySet()){
			String k = entry.getKey();
			String v = entry.getValue();
			if(!"sign".equals(k) && null != v && !"".equals(v)) {
				sb.append(k + "=" + v + "&");
			}
		}
		String plaintext = Md5.encrypt(sb.toString().replaceAll("&$", ""));
		String ciphertext = RSA.sign(plaintext, privateKey, "utf8"); 
		return ciphertext;
	}
	
	/**
	 * 校验签名
	 * @param map
	 * @param publicKey
	 * @return
	 */
	public static boolean verifySign(SortedMap<String, String> map, String publicKey){
		StringBuffer sb = new StringBuffer();
		for(Entry<String, String> entry : map.entrySet()){
			String k = entry.getKey();
			String v = entry.getValue();
			if(!"sign".equals(k) && null != v && !"".equals(v)) {
				sb.append(k + "=" + v + "&");
			}
		}
		
		String sign = map.get("sign");
		if(sign == null) {
			return false;
		}
		String plaintext = Md5.encrypt(sb.toString().replaceAll("&$", ""));
		return RSA.verify(plaintext, sign, publicKey, "utf8"); 
	}
	
}