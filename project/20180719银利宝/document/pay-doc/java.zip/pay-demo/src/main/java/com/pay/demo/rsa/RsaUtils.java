package com.pay.demo.rsa;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RsaUtils {

	/** 指定加密算法为RSA */
	private static final String ALGORITHM = "RSA";

	/**
	 * 生成秘钥对
	 */
	public static RsaKeyPair genKeyPairString(int length) {
		KeyPair keyPair = genKeyPair(length);
		// 得到私钥
		RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
		// 得到公钥
		RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
		// 得到公钥字符串
		String publicKeyString = Base64.encode(publicKey.getEncoded());
		// 得到私钥字符串
		String privateKeyString = Base64.encode(privateKey.getEncoded());
		return new RsaKeyPair(privateKeyString, publicKeyString);
	}

	/**
	 * 生成秘钥对
	 */
	public static KeyPair genKeyPair(int length) {
		// KeyPairGenerator类用于生成公钥和私钥对，基于RSA算法生成对象
		KeyPairGenerator keyPairGen = null;
		try {
			keyPairGen = KeyPairGenerator.getInstance(ALGORITHM);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		// 初始化密钥对生成器，密钥大小为96-1024位
		keyPairGen.initialize(length, new SecureRandom());
		// 生成一个密钥对，保存在keyPair中
		return keyPairGen.generateKeyPair();
	}

	/**
	 * 从字符串中加载公钥
	 *
	 * @param publicKeyString
	 *            公钥数据字符串
	 * @throws Exception
	 *             加载公钥时产生的异常
	 */
	public static RSAPublicKey toPublicKeyPair(String publicKeyString) {
		try {
			byte[] buffer = Base64.decode(publicKeyString);
			KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
			return (RSAPublicKey) keyFactory.generatePublic(keySpec);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("无此算法");
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException("公钥非法");
		} catch (NullPointerException e) {
			throw new RuntimeException("公钥数据为空");
		}
	}

	/**
	 * 从字符串加载私钥
	 * 
	 * @param privateKeyStr
	 * @return
	 * @throws Exception
	 */
	public static RSAPrivateKey toPrivateKeyPair(String privateKeyString) {
		try {
			byte[] buffer = Base64.decode(privateKeyString);
			PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(buffer);
			KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
			return (RSAPrivateKey) keyFactory.generatePrivate(keySpec);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("无此算法");
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException("私钥非法");
		} catch (NullPointerException e) {
			throw new RuntimeException("私钥数据为空");
		}
	}

	/**
	 * 加密方法
	 * 
	 * @param source  源数据
	 * @return
	 * @throws NoSuchPaddingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws Exception
	 */
	public static String encrypt(String publicKeyString, String source){
		try{
			Key publicKeyPair = toPublicKeyPair(publicKeyString);
			/** 得到Cipher对象来实现对源数据的RSA加密 */
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, publicKeyPair);
			byte[] b = source.getBytes();
			/** 执行加密操作 */
			byte[] b1 = cipher.doFinal(b);
			return Base64.encode(b1);
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException
				| BadPaddingException e) {
			e.printStackTrace();
			throw new RuntimeException("加密失败");
		}
		
		
	}

	/**
	 * 解密算法
	 * 
	 * @param cryptograph  密文
	 * @return
	 * @throws Exception
	 */
	public static String decrypt(String privateKeyString, String cryptograph) {
		try{
			Key privateKey = toPrivateKeyPair(privateKeyString);
			/** 得到Cipher对象对已用公钥加密的数据进行RSA解密 */
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, privateKey);
			byte[] b1 = Base64.decode(cryptograph);
			/** 执行解密操作 */
			byte[] b = cipher.doFinal(b1);
			return new String(b);
		
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException
				| BadPaddingException e) {
			throw new RuntimeException("解密失败");
		}
		

	}
}
