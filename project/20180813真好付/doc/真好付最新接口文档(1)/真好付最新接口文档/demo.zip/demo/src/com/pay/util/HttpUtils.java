package com.pay.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author 
 *
 * @date 2017年1月4日
 */
public class HttpUtils {
	private HttpUtils(){}

	/**
	 * 
	 * @param url
	 * @return
	 */
	public static String doPost(String url){
		return doPost(url,null,null,"UTF-8");
	}
	/**
	 * 
	 * @param url
	 * @param param
	 * @return
	 */
	public static String doPost(String url, Map<String, Object> param){
		return doPost(url,param,null,"UTF-8");
	}
	/**
	 *
	 * @param url
	 * @param param
	 * @return
	 */
	public static String doPost(String url, Map<String, Object> param,String charset){
		return doPost(url,param,null,charset);
	}
	/**
	 *
	 * @param url
	 *            要提交的目标url
	 * @param param
	 *            参数集合
	 * @param hearderMap
	 * 	 *         请求头
	 * @param charset
	 *            编码
	 * @return
	 */
	public static String doPost(String url, Map<String, Object> param,Map<String, Object> hearderMap, String charset) {
		// 定义一个可关闭的httpClient的对象
		CloseableHttpClient httpClient = null;

		// 定义httpPost对象
		HttpPost post = null;

		// 返回结果
		String result = null;

		try {
			// 1.创建httpClient的默认实例
			httpClient = HttpClients.createDefault();
			// 2.提交post
			post = new HttpPost(url);
			if(param!=null&&param.size()>0){
				// 3.设置参数
				List<NameValuePair> list = new ArrayList<>();
				// 4.迭代参数
				Iterator<Map.Entry<String, Object>> iterator = param.entrySet().iterator();
				while (iterator.hasNext()) {
					// 获得参数
					Map.Entry<String, Object> element = iterator.next();
					// 通过BasicNameValuePair(key,vlaue)填充参数，并放到集合
					list.add(new BasicNameValuePair(element.getKey(), String.valueOf(element.getValue())));
				}

				// 5.编码
				if (list.size() > 0) {
					if(StringUtils.isEmpty(charset)){
						UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list);
						post.setEntity(entity);
					}else{
						UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list, charset);
						post.setEntity(entity);
					}

				}

			}

			//设置请求头
			if(hearderMap!=null&&hearderMap.size()>0){
				Iterator<Map.Entry<String, Object>> iterator = hearderMap.entrySet().iterator();
				while (iterator.hasNext()) {
					// 获得参数
					Map.Entry<String, Object> element = iterator.next();
					post.setHeader(element.getKey(),String.valueOf(element.getValue()));
				}
			}

			//设置超时
			RequestConfig requestConfig = RequestConfig.custom()
					.setConnectTimeout(3000).setConnectionRequestTimeout(1000)
					.setSocketTimeout(3000).build();
			post.setConfig(requestConfig);

			// 执行
			CloseableHttpResponse response = httpClient.execute(post);
			try {
				if (response != null) {
					HttpEntity httpEntity = response.getEntity();
					// 如果返回的内容不为空
					if (httpEntity != null) {
						result = EntityUtils.toString(httpEntity);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				//关闭response
				response.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				//关闭资源
				if(httpClient!=null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return result;
	}


	public static String doGet(String url){
		return doGet(url,null);
	}
	/**
	 *
	 * @param url
	 * @param hearderMap 请求头
	 * @param charset 编码
	 * @return
	 */
	public static String doGet(String url,Map<String, Object> hearderMap ) {
		// 定义一个可关闭的httpClient的对象
		CloseableHttpClient httpClient = null;

		// 定义httpPost对象
		HttpGet get = null;

		// 返回结果
		String result = null;

		try {
			// 1.创建httpClient的默认实例
			httpClient = HttpClients.createDefault();
			// 2.提交post
			get = new HttpGet(url);

			//设置请求头
			if(hearderMap!=null&&hearderMap.size()>0){
				Iterator<Map.Entry<String, Object>> iterator = hearderMap.entrySet().iterator();
				while (iterator.hasNext()) {
					// 获得参数
					Map.Entry<String, Object> element = iterator.next();
					get.setHeader(element.getKey(),String.valueOf(element.getValue()));
				}
			}

			//设置超时
			RequestConfig requestConfig = RequestConfig.custom()
					.setConnectTimeout(3000).setConnectionRequestTimeout(1000)
					.setSocketTimeout(3000).build();
			get.setConfig(requestConfig);

			// 执行
			CloseableHttpResponse response = httpClient.execute(get);
			try {
				if (response != null) {
					HttpEntity httpEntity = response.getEntity();
					// 如果返回的内容不为空
					if (httpEntity != null) {
						result = EntityUtils.toString(httpEntity);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				//关闭response
				response.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				//关闭资源
				if(httpClient!=null) {
					httpClient.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return result;
	}


}

