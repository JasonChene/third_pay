package com.pay.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

/**
 * @version 1.0
 * @Date 2018/3/11 12:12
 * @since JDK1.8
 */
public class SignUtil {

    public static boolean verify(SortedMap<String,Object> map,String sign,String secretKey){
        if(map==null||map.size()==0){
            return false;
        }
        if(StringUtils.isEmpty(sign)){
            return false;
        }
        String signature = buildSgin(map,secretKey);
        if(sign.equalsIgnoreCase(signature)){
            return true;
        }
        return false;
    }

    public static String  buildSgin(SortedMap<String,Object> map, String secretKey){
        if(map==null||map.size()==0){
            return "";
        }

        StringBuffer sb = new StringBuffer();
        Iterator<Map.Entry<String, Object>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Object> entry = it.next();
            String k = entry.getKey();
            Object v = entry.getValue();
            if (null != v && !"".equals(v) && !"sign".equals(k)
                    && !"key".equals(k)&&!"signature".equals(k)) {
                sb.append(k + "=" + v + "&");
            }

        }
        sb.append("key=" + secretKey);

        System.out.println(sb.toString());
        String sign = EncryptUtils.MD5(sb.toString());
        System.out.println("sign="+sign);
        return sign.toUpperCase();
    }

}

