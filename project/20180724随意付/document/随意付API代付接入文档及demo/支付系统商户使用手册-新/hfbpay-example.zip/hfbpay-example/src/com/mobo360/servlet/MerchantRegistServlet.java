package com.mobo360.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

public class MerchantRegistServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/xml; charset=UTF-8");
		// 以下两句为取消在本地的缓存
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache");
		PrintWriter out = response.getWriter();
		String selName = request.getParameter("selName");
		Map<String,String> map = getElements(request);
		
		StringBuffer sb = new StringBuffer();
	    sb.append("<vals>");
	    if(!"branchBank".equals(selName)){
	    	for(String key:map.keySet()){
		    	sb.append("<val>"+map.get(key)+"</val>");
		    }
	    }else{
	    	for(String key:map.keySet()){
		    	sb.append("<val><k>"+key+"</k><v>"+map.get(key)+"</v></val>");
		    }
	    }
        sb.append("</vals>"); 
        out.write(sb.toString());
        out.close();
	}
	
	private Map<String,String> getElements(HttpServletRequest request) throws UnsupportedEncodingException{
		String selName = request.getParameter("selName");
		String province = request.getParameter("province");
		String city = request.getParameter("city");
		String bank = request.getParameter("bank");
		if(StringUtils.isNotBlank(province)){
			province = new String(province.getBytes("ISO-8859-1"), "UTF-8");
		}
		if(StringUtils.isNotBlank(city)){
			city = new String(city.getBytes("ISO-8859-1"), "UTF-8");
		}
		if(StringUtils.isNotBlank(bank)){
			bank = new String(bank.getBytes("ISO-8859-1"), "UTF-8");
		}
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		Map<String,String> map = new HashMap<String,String>();
		try {
			Class.forName("org.sqlite.JDBC");
			String sqliteJdbc = "jdbc:sqlite::resource:bankcode.db";
			connection = DriverManager.getConnection(sqliteJdbc);
			
			String sql = "";
			if("province".equals(selName)){
				sql = "select province as val from bank group by province";
				statement = connection.prepareStatement(sql);
			}else if("city".equals(selName)){
				sql = "select city as val from bank where province=? group by city";
				statement = connection.prepareStatement(sql);
				statement.setString(1, province);
			}else if("bank".equals(selName)){
				sql = "select bank as val from bank where province=? and city=? group by bank";
				statement = connection.prepareStatement(sql);
				statement.setString(1, province);
				statement.setString(2, city);
			}else if("branchBank".equals(selName)){
				sql = "select \"no\" as key,branch_bank as val from bank where province=? and city=? and bank=?";
				statement = connection.prepareStatement(sql);
	        	statement.setString(1, province);
	        	statement.setString(2, city);
	        	statement.setString(3, bank);
			}
			
	        rSet = statement.executeQuery();
	        
	        if(!"branchBank".equals(selName)){
	        	int i = 0;
	        	while (rSet.next()) {
					map.put(""+i++, rSet.getString("val"));
				}
	        }else{
	        	while (rSet.next()) {
					map.put(rSet.getString("key"), rSet.getString("val"));
				}
	        }
			
			return map;
		        
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (rSet != null)
					rSet.close();
				if (statement != null)
					statement.close();
				if (connection != null)
					connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doGet(req, resp);
	}

}
