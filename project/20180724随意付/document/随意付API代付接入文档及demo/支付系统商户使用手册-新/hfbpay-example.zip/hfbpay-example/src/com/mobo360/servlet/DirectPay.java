package com.mobo360.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.mobo360.merchant.api.CustRealPayResponseEntity;
import com.mobo360.merchant.api.HttpXmlClient;
import com.mobo360.merchant.api.Mobo360Config;
import com.mobo360.merchant.api.Mobo360Merchant;
import com.mobo360.merchant.api.Mobo360SignUtil;

public class DirectPay extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public DirectPay() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			// 签名初始化
			Mobo360SignUtil.init();

			// 组织输入数据
			Map<String, String> requestMap = new HashMap<String, String>();
			request.setCharacterEncoding("utf-8");
			requestMap.put("apiName", Mobo360Config.MOBAOPAY_APINAME_DS);
			requestMap.put("apiVersion", Mobo360Config.MOBAOPAY_API_VERSION);
			requestMap.put("platformID", Mobo360Config.PLATFORM_ID);
			requestMap.put("merchNo", Mobo360Config.MERCHANT_ACC);
			requestMap.put("orderNo", request.getParameter("orderNo"));
			requestMap.put("tradeDate", request.getParameter("tradeDate"));
			requestMap.put("Amt", request.getParameter("Amt"));
			requestMap.put("merchUrl", Mobo360Config.MERCHANT_NOTIFY_URL);
			requestMap.put("merchParam", request.getParameter("merchParam"));
			requestMap.put("bankAccName", request.getParameter("bankAccName"));
			requestMap.put("bankName", request.getParameter("bankName"));
			requestMap.put("bankCode", request.getParameter("bankCode"));
			requestMap.put("bankAccNo", request.getParameter("bankAccNo"));
			requestMap.put("tradeSummary", request.getParameter("tradeSummary"));

	    	
			String paramsStr = Mobo360Merchant.generateDirectPay(requestMap);
			String signStr = Mobo360SignUtil.signData(paramsStr);
			paramsStr = paramsStr + "&signMsg=" + signStr;

			// 发起请求并获取返回数据
//			String responseMsg = transact(paramsStr,
//					Mobo360Config.MOBAOPAY_GETWAY);

			requestMap.put("signMsg", signStr);
			String responseMsg = HttpXmlClient.post(Mobo360Config.MOBAOPAY_GETWAY, requestMap);  
			//String responseMsg = transact(paramsStr,"http://192.168.0.11:7001/cashier/cgi-bin/netpayment/pay_gate.cgi");
			
			// 处理返回数据
			CustRealPayResponseEntity entity = new CustRealPayResponseEntity();
			entity.parseDS(responseMsg);
			StringBuffer sbHtml = new StringBuffer();
			sbHtml
					.append("<tr><td align=\"left\" width=\"30%\">&nbsp;&nbsp;响应码</td><td align=\"left\">&nbsp;&nbsp;"
							+ entity.getRespCode() + "</td></tr>");
			sbHtml
					.append("<tr><td align=\"left\" width=\"30%\">&nbsp;&nbsp;响应描述</td><td align=\"left\">&nbsp;&nbsp;"
							+ entity.getRespDesc() + "</td></tr>");
			if ("00".equals(entity.getRespCode())) {
				sbHtml.append("<tr><td align=\"left\" width=\"30%\">&nbsp;&nbsp;支付订单号</td><td align=\"left\">&nbsp;&nbsp;"
							+ entity.getBatchNo() + "</td></tr>");
				sbHtml.append("<tr><td align=\"left\" width=\"30%\">&nbsp;&nbsp;支付日期</td><td align=\"left\">&nbsp;&nbsp;"
					+ entity.getAccDate() + "</td></tr>");
			}
			request.setAttribute("msg",sbHtml.toString());
			request.getRequestDispatcher("DirectPay.jsp").forward(request,response);
		} catch (Exception e) {
			request.setAttribute("msg",e.getMessage());
			request.getRequestDispatcher("DirectPay.jsp").forward(request,response);
		}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			doGet(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

	
	
	public static String transact(String paramsStr, String serverUrl)
			throws Exception {

		if (StringUtils.isBlank(serverUrl) || StringUtils.isBlank(paramsStr)) {
			throw new NullPointerException("请求地址或请求数据为空!");
		}

		myX509TrustManager xtm = new myX509TrustManager();
		myHostnameVerifier hnv = new myHostnameVerifier();
		ByteArrayOutputStream respData = new ByteArrayOutputStream();

		byte[] b = new byte[8192];
		String result = "";
		try {
			SSLContext sslContext = null;
			try {
				sslContext = SSLContext.getInstance("TLS");
				X509TrustManager[] xtmArray = new X509TrustManager[] { xtm };
				sslContext.init(null, xtmArray,
						new java.security.SecureRandom());
			} catch (GeneralSecurityException e) {
				e.printStackTrace();
			}

			if (sslContext != null) {
				HttpsURLConnection.setDefaultSSLSocketFactory(sslContext
						.getSocketFactory());
			}
			HttpsURLConnection.setDefaultHostnameVerifier(hnv);

			// 匹配http或者https请求
			URLConnection conn = null;
			if (serverUrl.toLowerCase().startsWith("https")) {
				HttpsURLConnection httpsUrlConn = (HttpsURLConnection) (new URL(
						serverUrl)).openConnection();
				httpsUrlConn.setRequestMethod("POST");
				conn = httpsUrlConn;
			} else {
				HttpURLConnection httpUrlConn = (HttpURLConnection) (new URL(
						serverUrl)).openConnection();
				httpUrlConn.setRequestMethod("POST");
				conn = httpUrlConn;
			}

			conn.setConnectTimeout(5000);
			conn.setReadTimeout(30000);
			conn.setRequestProperty(
					"User-Agent",
					"Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.8.1.1) Gecko/20061204 Firefox/2.0.0.3");
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("connection", "close");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.getOutputStream().write(paramsStr.getBytes("utf-8"));
			conn.getOutputStream().flush();

			int len = 0;
			try {
				while (true) {
					len = conn.getInputStream().read(b);
					if (len <= 0) {
						conn.getInputStream().close();
						break;
					}
					respData.write(b, 0, len);
				}
			} catch (SocketTimeoutException ee) {
				throw new RuntimeException("读取响应数据出错！" + ee.getMessage());
			}

			// 返回给商户的数据
			result = respData.toString("utf-8");
			if (StringUtils.isBlank(result)) {
				throw new RuntimeException("返回参数错误！");
			}
		} catch (Exception e) {
			throw new RuntimeException("发送POST请求出现异常！" + e.getMessage());
		}

		return result;
	}
}

class myX509TrustManager implements X509TrustManager {

	public void checkClientTrusted(X509Certificate[] chain, String authType) {
	}

	public void checkServerTrusted(X509Certificate[] chain, String authType) {
	}

	public X509Certificate[] getAcceptedIssuers() {
		return null;
	}
}

class myHostnameVerifier implements HostnameVerifier {

	public boolean verify(String hostname, SSLSession session) {
		return true;
	}
	
}
