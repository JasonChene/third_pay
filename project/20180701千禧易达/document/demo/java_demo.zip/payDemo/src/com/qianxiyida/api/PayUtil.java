package com.qianxiyida.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import sun.misc.BASE64Encoder;

import com.itrus.util.sign.RSAWithSoftware;

public class PayUtil {
	private static final String url = "http://api.qianxiyida.com/ecpay/xbdo";
	// 平台公钥
	private static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0tU8imsKRK3J5nCT1PQuZujwhykJP6TOZZAZc6qSW0CSqFooQaO6XPQl2lmRMknfR83SYPjphDpUaqlKxswYY3DO/D9oj9lRATMwou3HKLUJ6lsQ+VeCDx01lq0OaGHRaTb2R3r3wc+IbleQnphST8Au7/ZDfEYnnK9qCSMcqBZhDAamyBQa5ykRqX/BRsOL9mwk0v39mZewAt4tsvaelWJu6E+KY5guZQtib4q8kzEzT3amO0WOV5/c5SdG0MBkc+XE9Wcb6JOjocdG9yCNnVVh0NEjrGB7qs3bq0zvQ89dajZIh8yHPIQlnCKwIB3XCVKvR2/RjbhHSeYdmHuXhQIDAQAB";
	// 商户私钥
	private static final String merchant_private_key = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCdWnNKBN2U1auPF2FXRLfKGuMYOUObxrZsWtVr//3Z5/ADcCC6T4q9JHWFubTe/1YYGKVVEz5AseQlS6A4AIUGsyRRiuAN6VvxVOmmg0pcvm8cUaMd2viRCnb2JtaRrjPpeoKxNu+9bSotwFfOx6HeImKF0uFr7Sfhx6xA/P2s5pVLfkUduc29fOKAgbR6XP49mfvcr12EwIr38H2qNPyAHgrLl/6cfcYYd5xBveDPh+9h2JMqhHwJzSTbHWA/rLDLHsnhS0OhTiliB9pyYCra5t0HL/17WMRgTdnxyQGhbA9d3/rLTUwIulq/ZquJoiGpMDWjs2K6WR3rHNGY+qfpAgMBAAECggEAZ7aCXrsuQTdESKAkbJzCdteZ7xFvWnFzM5/7I6Aq9UFGlT2GlMZwr5IkU+u/J2wslt1Hu/dfBM07jsl15POSuoPA4G4kl4bELyDEkBfhH5f1LDkyxi7Zvt+i4UNgEc08MhupoJyRD82wC0/HkGdMbVlEjugb5EMAEnTFOGCH4zlfVH6BxwbUwA1F2gQ2GktcYke6wKUFRlgSZA19buhk+8/IMmhGjgKwop67lo3r++GsLJ+I/K1UK5UBoGfXMtLm3cSWDfcm7us3yEOrjQpH7IdlmV0+lbwDTZOFMAnJrQfJqXi4dwSsSCu7SMHASBYmvyPfZ/ilY7oWjRb1xY1x8QKBgQDQNqFccSRpKHPadMlkJ+2nirWbQCcF9F+IW2MnU9KHoU77Dibz++dCNvXYanRuzLPdpfbLA8T0bfFCTvNT1wRNTiIjFBpSHH+UAFjJqZr4tlwzVIdTqbx7t0joBxC0NFd7Yb6ccDYBf5QvJ+wBR+Xdl6BB7G3L54zNMr/4sQazkwKBgQDBd5ZMm/A8N7eE7sNJ9DgQeOISYTjGD5m763hA//Eqq28BUFge9BKfofqUtL0LQk2PycyONn+1WxZiSkzyJo2ja0gn6ZVtatADeY8WX+iDDtrS2MjnV3ZZJm403W1Pftnj17Q3E6J4/opm7Lgs++Inozgzjot3UOqlNn4pK9PcEwKBgDEgYqw0CdpB8CvgGFBoV1uLj9PkrBBsm0nJ/jgeP/M+bSsxKKGyktr9qr34SCaIZ/vpF7TI2+SsOBtkE2d5uQsgX0+Vg6xSCwv5lPln6ie6p0B5NkDYMJ+kHDCa0icinm1/H4E7vJJX7re9nKKkuyiwiOBlD3bn2EHmMoNUCXe/AoGAEmiqqId+CHzUvZVqh7LxUr/t4wnVOSNq4XK6cpToAcNmQJ3AhNF8pCvpiBTamCOq9a+iAzY0WLFeI+QmBjSc7ZvbtdCII20ydeIvN1XQ7geP0thF5Z1w6XK6sdUP/ax4VzHDOCpqH1E5IioMLFubXWIuitlZc/UDHs1cm9ZLxnkCgYABUBB7C4FtJeI9X1+srShYvgRjfeNvylLxLYnMKsqnlVCrq2vEIMXBRg69RHKUyGCw5VglVjl+/vWMSne6x9Qn8D+WZ1dYuEvr0oB1oOlaNGD/EK6ioe5BNT6wjzKlajflVxsjmoetVA15pfcHi3FwqDbyLcsykzc7+K9INTMj+g==";

	public static void main(String[] args) throws Exception {
		String sellerId = "561713165";
		createPayOrder(sellerId);
	}

	// 获取回调报文的方法，
	private String getPostData(HttpServletRequest request) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				request.getInputStream()));
		String line = null;
		StringBuffer sb = new StringBuffer();
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}
		String data = sb.toString().trim();
		return data;
	}

	private static void createPayOrder(String sellerId) throws Exception {
		Map<String, Object> map = new TreeMap<String, Object>();
		map.put("seller_id", sellerId);
		map.put("order_type", "2704");
		map.put("out_trade_no", getPayNo());
		map.put("pay_body", "teweteset");
		map.put("total_fee", "62100");
		map.put("notify_url", "http://www.baidu.com");
		map.put("return_url", "http://www.baidu.com");
		map.put("spbill_create_ip", "129.192.14.18");
		map.put("spbill_times", System.currentTimeMillis());
		map.put("noncestr", getRandomStringByLength(32, 2));
		map.put("remark", "");
		map.put("sign", RSAWithSoftware.signByPrivateKey(JUtil.getSignStr(map),
				merchant_private_key));
		String json = JUtil.toJsonString(map).replaceAll("\\\\", "");
		BASE64Encoder decoder = new BASE64Encoder();
		json = new String(decoder.encodeBuffer(json.getBytes()));
		String resp = getPostJSONContent(url, json);
		System.out.println("json:" + json);
		System.out.println("resp:" + resp);
		Map<String, Object> map2 = JUtil.toMap(resp);
		if (map2.get("state").equals("00")) {
			String sign2 = map2.get("sign").toString();
			if (RSAWithSoftware.validateSignByPublicKey(JUtil.getSignStr(map2),
					publicKey, sign2)) {
				System.out.println("返回验证成功");
				System.out.println(map2.get("pay_url"));
			}
		}
	}

	private static void queryMoney(String sellerId) throws Exception {
		Map<String, Object> map = new TreeMap<String, Object>();
		map.put("seller_id", sellerId);
		map.put("order_type", "1020");
		map.put("noncestr", getPayNo());
		map.put("sign", RSAWithSoftware.signByPrivateKey(JUtil.getSignStr(map),
				merchant_private_key));
		map.remove("seller_key");
		String json = JUtil.toJsonString(map).replaceAll("\\\\", "");
		BASE64Encoder decoder = new BASE64Encoder();
		json = new String(decoder.encodeBuffer(json.getBytes()));
		String resp = getPostJSONContent(url, json);
		System.out.println("json:" + json);
		System.out.println("resp:" + resp);
	}

	private static void queryOrder(String sellerId) throws Exception {
		Map<String, Object> map = new TreeMap<String, Object>();
		map.put("seller_id", sellerId);
		map.put("order_type", "1010");
		map.put("out_trade_no", "NqV5JufvuKsdR7rzb5I5EJtHVLHGR");
		map.put("sign", RSAWithSoftware.signByPrivateKey(JUtil.getSignStr(map),
				merchant_private_key));
		String json = JUtil.toJsonString(map).replaceAll("\\\\", "");
		BASE64Encoder decoder = new BASE64Encoder();
		json = new String(decoder.encodeBuffer(json.getBytes()));
		String resp = getPostJSONContent(url, json);
		System.out.println("json:" + json);
		System.out.println("resp:" + resp);
	}

	// 生成支付订单号
	public static String getPayNo() {
		return "N" + getRandomStringByLength(24, 2);
	}

	public static String getRandomStringByLength(int length, int type) {
		String base = "abcdefghijklmnopqrstuvwxyz0123456789";
		switch (type) {
		case 1:
			base = "0123456789";
			break;
		case 2:
			base = "abcdefghijklmnopqrstuvwxyzQWERTYUIOPLKJMNHBGVFCDXSZA0123456789";
			break;
		default:
			break;
		}
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; ++i) {
			int number = random.nextInt(base.length());
			sb.append(base.charAt(number));
		}
		return sb.toString();
	}

	private static String getSign(Map<String, Object> map)
			throws NoSuchAlgorithmException {
		ArrayList<String> list = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			if (entry.getValue() != "") {
				list.add(entry.getKey() + "=" + entry.getValue() + "&");
			}
		}
		int size = list.size();
		String[] arrayToSort = list.toArray(new String[size]);
		Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < size; i++) {
			sb.append(arrayToSort[i]);
		}
		String result = sb.deleteCharAt(sb.length() - 1).toString();
		System.out.println("str:" + result);
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(result.getBytes());
		return new BigInteger(1, md.digest()).toString(16);
	}

	// http POST 请求
	private static String getPostJSONContent(String url, String json) {
		PrintWriter out = null;
		BufferedReader in = null;
		String result = "";
		try {
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			URLConnection conn = realUrl.openConnection();
			// 设置通用的请求属性
			conn.setConnectTimeout(1000 * 100);
			conn.setReadTimeout(1000 * 100);
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			conn.setRequestProperty("Content-Type", "application/json");
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			out = new PrintWriter(conn.getOutputStream());
			// 发送请求参数
			out.print(json);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(
					new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			System.out.println("发送 POST 请求出现异常！" + e);
			e.printStackTrace();
		}
		// 使用finally块来关闭输出流、输入流
		finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}
}
