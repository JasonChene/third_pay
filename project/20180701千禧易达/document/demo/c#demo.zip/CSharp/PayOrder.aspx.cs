﻿using System;
using System.Web;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;


namespace CSharpTestPay
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string seller_id = Request.Form["seller_id"].ToString().Trim();
                string order_type = Request.Form["order_type"].ToString().Trim();
                string pay_body = Request.Form["pay_body"].ToString().Trim();
                string out_trade_no = Request.Form["out_trade_no"].ToString().Trim();
                string total_fee = Request.Form["total_fee"].ToString().Trim();
                string notify_url = "http:/www.baidu.com";
                string return_url = "http:/www.baidu.com";
                string spbill_create_ip = "122.15.16.27";
                string spbill_times = DateTime.Today.ToLongTimeString();
                string noncestr = DateTime.Today.ToLongTimeString();
                string remark = "orderno";

                string signSrc= "";
                
	            //组织订单信息
	            if(noncestr!="") {
		            signSrc=signSrc+"noncestr="+noncestr+"&";
	            }
	            if(notify_url!="") {
		            signSrc=signSrc+"notify_url="+notify_url+"&";
	            }
                if (order_type != "")
                {
                    signSrc = signSrc + "order_type=" + order_type + "&";
                }
	            if(out_trade_no!="") {
		            signSrc=signSrc+"out_trade_no="+out_trade_no+"&";
	            }
	            if(pay_body!="") {
		            signSrc=signSrc+"pay_body="+pay_body+"&";
	            }
	            if (remark!="") {
		            signSrc=signSrc+"remark="+remark+"&";
	            }
	            if (return_url!="") {
		            signSrc=signSrc+"return_url="+return_url+"&";
	            }
	            if (seller_id!="") {
		            signSrc=signSrc+"seller_id="+seller_id+"&";
	            }
	            if(spbill_create_ip!="") {
		            signSrc=signSrc+"spbill_create_ip="+spbill_create_ip+"&";
	            }
	            if(spbill_times!="") {
		            signSrc=signSrc+"spbill_times="+spbill_times+"&";
	            }
	            if(total_fee!="") {
		            signSrc=signSrc+"total_fee="+total_fee;
	            }
                    
                string merchant_private_key = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCdWnNKBN2U1auPF2FXRLfKGuMYOUObxrZsWtVr//3Z5/ADcCC6T4q9JHWFubTe/1YYGKVVEz5AseQlS6A4AIUGsyRRiuAN6VvxVOmmg0pcvm8cUaMd2viRCnb2JtaRrjPpeoKxNu+9bSotwFfOx6HeImKF0uFr7Sfhx6xA/P2s5pVLfkUduc29fOKAgbR6XP49mfvcr12EwIr38H2qNPyAHgrLl/6cfcYYd5xBveDPh+9h2JMqhHwJzSTbHWA/rLDLHsnhS0OhTiliB9pyYCra5t0HL/17WMRgTdnxyQGhbA9d3/rLTUwIulq/ZquJoiGpMDWjs2K6WR3rHNGY+qfpAgMBAAECggEAZ7aCXrsuQTdESKAkbJzCdteZ7xFvWnFzM5/7I6Aq9UFGlT2GlMZwr5IkU+u/J2wslt1Hu/dfBM07jsl15POSuoPA4G4kl4bELyDEkBfhH5f1LDkyxi7Zvt+i4UNgEc08MhupoJyRD82wC0/HkGdMbVlEjugb5EMAEnTFOGCH4zlfVH6BxwbUwA1F2gQ2GktcYke6wKUFRlgSZA19buhk+8/IMmhGjgKwop67lo3r++GsLJ+I/K1UK5UBoGfXMtLm3cSWDfcm7us3yEOrjQpH7IdlmV0+lbwDTZOFMAnJrQfJqXi4dwSsSCu7SMHASBYmvyPfZ/ilY7oWjRb1xY1x8QKBgQDQNqFccSRpKHPadMlkJ+2nirWbQCcF9F+IW2MnU9KHoU77Dibz++dCNvXYanRuzLPdpfbLA8T0bfFCTvNT1wRNTiIjFBpSHH+UAFjJqZr4tlwzVIdTqbx7t0joBxC0NFd7Yb6ccDYBf5QvJ+wBR+Xdl6BB7G3L54zNMr/4sQazkwKBgQDBd5ZMm/A8N7eE7sNJ9DgQeOISYTjGD5m763hA//Eqq28BUFge9BKfofqUtL0LQk2PycyONn+1WxZiSkzyJo2ja0gn6ZVtatADeY8WX+iDDtrS2MjnV3ZZJm403W1Pftnj17Q3E6J4/opm7Lgs++Inozgzjot3UOqlNn4pK9PcEwKBgDEgYqw0CdpB8CvgGFBoV1uLj9PkrBBsm0nJ/jgeP/M+bSsxKKGyktr9qr34SCaIZ/vpF7TI2+SsOBtkE2d5uQsgX0+Vg6xSCwv5lPln6ie6p0B5NkDYMJ+kHDCa0icinm1/H4E7vJJX7re9nKKkuyiwiOBlD3bn2EHmMoNUCXe/AoGAEmiqqId+CHzUvZVqh7LxUr/t4wnVOSNq4XK6cpToAcNmQJ3AhNF8pCvpiBTamCOq9a+iAzY0WLFeI+QmBjSc7ZvbtdCII20ydeIvN1XQ7geP0thF5Z1w6XK6sdUP/ax4VzHDOCpqH1E5IioMLFubXWIuitlZc/UDHs1cm9ZLxnkCgYABUBB7C4FtJeI9X1+srShYvgRjfeNvylLxLYnMKsqnlVCrq2vEIMXBRg69RHKUyGCw5VglVjl+/vWMSne6x9Qn8D+WZ1dYuEvr0oB1oOlaNGD/EK6ioe5BNT6wjzKlajflVxsjmoetVA15pfcHi3FwqDbyLcsykzc7+K9INTMj+g==";
                    //私钥转换成C#专用私钥
                merchant_private_key = testOrder.HttpHelp.RSAPrivateKeyJava2DotNet(merchant_private_key);
                //签名
                string signData = testOrder.HttpHelp.RSASign(signSrc, merchant_private_key);

                string resp = testOrder.HttpHelp.Post("http://api.qianxiyida.com/ecpay/xbdo", "{\"noncestr\":\"" + noncestr + "\",\"notify_url\":\"" + notify_url + "\",\"order_type\":\"" + order_type + "\",\"out_trade_no\":\"" + out_trade_no + "\",\"pay_body\":\"" + pay_body + "\",\"remark\":\"" + remark + "\",\"return_url\":\"" + return_url + "\",\"seller_id\":\"" + seller_id + "\",\"spbill_create_ip\":\"" + spbill_create_ip + "\",\"spbill_times\":\"" + spbill_times + "\",\"total_fee\":\"" + total_fee + "\",\"sign\":\"" + signData + "\"}");
                respD.Value = resp;
            }
            finally
            {
            }
        }
    }
}