package com.zhifu.pay.dto;

import java.io.Serializable;

public interface IRequestDTO  extends Serializable{

}
