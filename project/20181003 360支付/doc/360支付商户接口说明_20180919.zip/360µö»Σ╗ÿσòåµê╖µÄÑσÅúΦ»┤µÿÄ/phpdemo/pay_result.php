<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta http-equiv="cleartype" content="on">
    <meta name="renderer" content="webkit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>支付结果前台回调页面</title>
    <link type="text/css" href="css/style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>

<h3 align="center">支付结果前台回调页面， 成功或者失败，逻辑自己处理</h3>

<script type="text/javascript">
    $(function() {

    });
</script>
</body>
</html>
