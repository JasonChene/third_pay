<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$userid='10000';
$userkey='760684862f5fdc8f36d0871e1296ec1692380f37';
?>
