﻿<?php
//phpinfo();
//链接数据库操作

//接收参数，解析post的json
$json_data = json_decode(file_get_contents("php://input"), true);

//接受返回数据验证开始
//md5验证
$merchant_id = "88888"; //青蛙金服分配的商户号
$compKey = "3383adfda18e78552a7c1ff66fba2d2e"; //青蛙金服分配的密钥

$sign = md5('merchant_id=' . $merchant_id . '&order_id=' . $json_data['order_id'] . '&amount=' . $json_data['amount'] . '&sign=' . $compKey);

if($sign == $json_data['sign']){
  // 验签成功

  //改变订单状态，及其他业务修改

  echo "success";
  //接收通知后必须输出”success“代表接收成功。
}

?>