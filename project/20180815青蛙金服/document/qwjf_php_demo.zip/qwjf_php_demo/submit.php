﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>青蛙金服</title>
</head>
<!--微信支付请求提交页-->
<?php
  /**************************请求参数**************************/
  $merchant_id = "88888"; //青蛙金服分配的商户号
  $compKey = "3383adfda18e78552a7c1ff66fba2d2e"; //青蛙金服分配的密钥
  $order_id = date("ymdHis", time());
  $amount = $_POST['amount'];
  $pay_method = $_POST['pay_method'];
  $return_url = "http://www.123456.com/php_demo/";
  $notify_url = "http://www.123456.com/php_demo/chuli.php";
  $sign = md5('merchant_id=' . $merchant_id . '&order_id=' . $order_id . '&amount=' . $_POST['amount'] . '&sign=' . $compKey);
?>

<body onLoad="document.payform.submit();">
	<form name='payform' action='http://188nx.com/pay' method='get'>
		<input type='hidden' name='merchant_id' value='<?php echo $merchant_id; ?>'>
		<input type='hidden' name='order_id' value='<?php echo $order_id; ?>'>
		<input type='hidden' name='amount' value='<?php echo $amount; ?>'>
		<input type='hidden' name='notify_url' value='<?php echo $notify_url; ?>'>
		<input type='hidden' name='return_url' value='<?php echo $return_url; ?>'>
		<input type='hidden' name='pay_method' value='<?php echo $pay_method; ?>'>
		<input type='hidden' name='sign' value='<?php echo $sign; ?>'>
	</form>
</body>

</html>