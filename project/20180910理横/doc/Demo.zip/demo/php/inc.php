<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$userid='10000';
$userkey='7897062fc648ca140512b0c7bf66ff67009e1e86';
?>
