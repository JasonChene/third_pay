<?php
ini_set('date.timezone', 'PRC');
require_once 'phpqrcode.php';
require_once 'merchants.php';
require_once 'lib.php';