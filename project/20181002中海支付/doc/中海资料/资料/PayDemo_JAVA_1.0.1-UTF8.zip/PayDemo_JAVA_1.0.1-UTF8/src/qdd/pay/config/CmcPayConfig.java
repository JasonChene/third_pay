package qdd.pay.config;

/**
 * Created by xieyuxing on 2017/9/18.
 */
public class CmcPayConfig {
	
    //密匙
    public static final String KEY="f5fde174bab030541d625996ef325139";
    //appid
    public static final String UID="7RZLYE7H";
    // 千应api的post提交接口服务器地址
    public static final String URL="https://pay.zhonghaipay.com/pay/create";
    // 商户网页的编码方式【请根据实际情况自行配置】
    public static final String CHARSET="utf-8";
    public static final String TOKEN="ABCDEFG";
    
}
