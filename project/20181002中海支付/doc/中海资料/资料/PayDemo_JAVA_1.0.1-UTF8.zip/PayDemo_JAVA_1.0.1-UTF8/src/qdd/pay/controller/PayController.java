package qdd.pay.controller;

import java.io.BufferedReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.LinkedMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import net.sf.json.JSONObject;
import qdd.pay.config.CmcPayConfig;
import qdd.pay.util.CmcPayOuterRequestUtil;
import qdd.pay.util.CmcPayTool;

@Controller
public class PayController {
	
	/**
	 * 请求地址
	 * @param order_amount 金额
	 * @throws Exception
	 */
	@RequestMapping(value = "/send")
	public void send(String order_amount) throws Exception {
		String orderid = "OFHWL"+new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());// 订单号，可以用户自定义，如果传入空值则会生成一个UUID值作为订单号
		String repson = CmcPayTool.submitOrder(order_amount, orderid);
		System.out.println("支付返回："+repson);
		JSONObject json = JSONObject.fromObject(repson);
		JSONObject data = (JSONObject)json.get("data");
		Map<String, Object> params = new HashMap<String, Object>();
		if("00".equals(data.get("resp_code"))){
			//成功
			params.clear();
			params.put("order_no", orderid);
			params.put("qrCode", data.get("payment"));
			System.out.println(params);
		}else{
			//失败
			System.out.println(data);
		}
		
	}
	
	/**
	 * 支付回调
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/notify")
	public void notify(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("============开始回调===============");
		StringBuffer json = new StringBuffer();
		String line = null;
		try {
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				json.append(line);
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		System.out.println("params:" + json.toString());
		JSONObject jsonObj = JSONObject.fromObject(json.toString());
		LinkedMap map=new LinkedMap();
		map.put("amount", (String)jsonObj.get("amount"));
		map.put("appid", (String)jsonObj.get("appid"));
		map.put("currency_type", (String)jsonObj.get("currency_type"));
		map.put("goods_name", (String)jsonObj.get("goods_name"));
		map.put("out_trade_no", (String)jsonObj.get("out_trade_no"));
		map.put("pay_id",(String)jsonObj.get("pay_id"));
		map.put("pay_no",(String)jsonObj.get("pay_no"));
		map.put("payment",(String)jsonObj.get("payment"));
		map.put("resp_code",(String)jsonObj.get("resp_code"));
		map.put("resp_desc",(String)jsonObj.get("resp_desc"));
		map.put("sign_type", (String)jsonObj.get("sign_type"));
		map.put("tran_amount", (String)jsonObj.get("tran_amount"));
		map.put("version", (String)jsonObj.get("version"));
        String _sign=  CmcPayOuterRequestUtil.getSign(map, CmcPayConfig.KEY);
		// 表示订单收款【成功】的情况，请根据实际情况自行处理
		if ("00".equals((String)jsonObj.get("resp_code")) && _sign.equals((String)jsonObj.get("sign")))
		{
			// 这里编写用户业务逻辑代码，如存储订单状态，自动发货等
			//TODO
			System.out.println("============回调成功并结束===============");
			response.getWriter().println("SUCCESS");
		} else {
			System.out.println("============回调失败并结束===============");
			response.getWriter().println("FAIL");
		}
	}
	
	public static void main(String[] args) {
		
	}
}
