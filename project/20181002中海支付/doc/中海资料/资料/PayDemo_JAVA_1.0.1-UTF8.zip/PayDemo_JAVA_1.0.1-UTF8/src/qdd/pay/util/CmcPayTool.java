package qdd.pay.util;


import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.collections.map.LinkedMap;

import qdd.pay.config.CmcPayConfig;

/**
 * Created by xieyuxing on 2017/9/22.
 */

public class CmcPayTool {

    public static String submitOrder(String amount, String orderid) throws Exception {
        if (orderid==null||orderid.trim().equals("")) orderid= "OFHWL"+new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        LinkedMap params=new LinkedMap();
        params.put("appid", CmcPayConfig.UID);
        params.put("pay_id", "WECHAT_NATIVE");
        params.put("version", "1.0");
        params.put("sign_type", "MD5");
        params.put("order_type", "2");
        params.put("currency_type", "CNY");
        Double d= Double.parseDouble(amount); 
        DecimalFormat df = new DecimalFormat("0.00"); 
        String s = df.format(d);
        params.put("total_fee", s);
        params.put("return_url", "");
        Base64.Encoder encoder = Base64.getEncoder();
        byte[] textByte = "乐彩支付".getBytes("UTF-8");
        params.put("goods_name", encoder.encodeToString(textByte));
        params.put("out_trade_no", orderid);
        String _sign=  CmcPayOuterRequestUtil.getSign(params, CmcPayConfig.KEY);
        params.put("sign", _sign);
        //token是用户自定义的字段，千应服务器会原址返回，请自定义此字段
        
        //插入订单
		// 保存订单 为未支付

        try {
            String urlWithParams=CmcPayOuterRequestUtil.post(CmcPayConfig.URL,params);
            return urlWithParams;
            //response.sendRedirect(urlWithParams);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}