﻿<?php
require_once 'inc.php';
$mer_order=$_POST['mer_order'];
$amount=$_POST['amount'];
$status=$_POST['status'];

$sign=$_POST['sign'];
//if($sign==$local_sign){//todo}//验证签名，业务处理
echo "success";
?>
