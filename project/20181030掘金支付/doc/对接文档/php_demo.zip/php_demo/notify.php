<?php
require_once 'inc.php';
$mer_order=$_POST['mer_order'];
$amount=$_POST['amount'];
$status=$_POST['status'];

$sign=$_POST['sign'];

echo "success";
?>
