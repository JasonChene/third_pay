<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$url='https://api.juejinpay.com/api/pay';
$mer_num='C100E17869R';
$mer_accesskey='736E178625F30059401F1F4A';
?>
