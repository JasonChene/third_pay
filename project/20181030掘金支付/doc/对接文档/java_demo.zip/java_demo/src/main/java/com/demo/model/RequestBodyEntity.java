package com.demo.model;


public class RequestBodyEntity {
    private String mer_num;   //商户号
    private String pay_way;   //支付通道
    private String money;  //订单金额
    private String goods_name;  //商品名称
    private String order_num; //订单号
    private String notify_url;  //通知地址
    private String return_url;  //回显地址
    private String version; // 系统版本号
    private String sign;  //签名

    public String getMer_num() {
        return mer_num;
    }

    public void setMer_num(String mer_num) {
        this.mer_num = mer_num;
    }

    public String getPay_way() {
        return pay_way;
    }

    public void setPay_way(String pay_way) {
        this.pay_way = pay_way;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getGoods_name() {
        return goods_name;
    }

    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name;
    }

    public String getOrder_num() {
        return order_num;
    }

    public void setOrder_num(String order_num) {
        this.order_num = order_num;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getReturn_url() {
        return return_url;
    }

    public void setReturn_url(String return_url) {
        this.return_url = return_url;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}