package com.demo.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.demo.model.RequestBodyEntity;
import com.demo.utils.MD5Utils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



@Controller
public class PayController {

    /**
     * ############################ 支付 ###############################
     */
    private static final String url = "https://api.juejinpay.com/api/pay";
    private static final String Mer_Num = "C100E17869R";
    private static final String Mer_AccessKey = "736E178625F30059401F1F4A";
    private static final String flag="&";


    @RequestMapping(value = "/")
    public ModelAndView index() {
        return new ModelAndView("pay");
    }

    /**
     * private String mer_num;   //商户号
     * private String pay_way;   //支付通道
     * private String money;  //订单金额
     * private String goods_name;  //商品名称
     * private String order_num; //订单号
     * private String notify_url;  //通知地址
     * private String return_url;  //回显地址
     * private String version;   //系统版本号
     * private String sign;  //签名
     **/
    @RequestMapping(value = "/pay", method = RequestMethod.POST)
    public void Pay(RequestBodyEntity requestBodyEntity, HttpServletRequest request, HttpServletResponse response, RedirectAttributes ra) throws Exception {
        Integer amount=Integer.parseInt(requestBodyEntity.getMoney())*100;
        Map<String, String> reqMap = new HashMap<>();
        reqMap.put("mer_num", Mer_Num);
        reqMap.put("pay_way", requestBodyEntity.getPay_way());
        reqMap.put("money",String.valueOf(amount) );
        reqMap.put("order_num", requestBodyEntity.getOrder_num());
        reqMap.put("goods_name", "一個栗子");
        reqMap.put("notify_url", requestBodyEntity.getNotify_url());
        reqMap.put("return_url",requestBodyEntity.getReturn_url());
        reqMap.put("version","1.0");


        StringBuffer sb = new StringBuffer();
        sb.append(Mer_Num).append(flag);
        sb.append(requestBodyEntity.getPay_way()).append(flag);
        sb.append(amount).append(flag);
        sb.append(requestBodyEntity.getOrder_num()).append(flag);
        sb.append("一個栗子").append(flag);
        sb.append(requestBodyEntity.getNotify_url()).append(flag);
        sb.append(requestBodyEntity.getReturn_url()).append(flag);
        sb.append("1.0").append(flag);
        sb.append(Mer_AccessKey);

       // C100E17869R&ZFBH5&10000&TEST15401199820004201&一個栗子&http://127.0.0.1:8080/test&http://127.0.0.1:8080/test/view&1.0&

        System.out.print("签名加密前数据{}"+sb.toString());
        String sign = MD5Utils.MD5(sb.toString(), "UTF-8");
        reqMap.put("sign", sign);



        String json = JSONObject.toJSONString(reqMap);
        request.setAttribute("orderNum", requestBodyEntity.getOrder_num());
        request.setAttribute("amount", requestBodyEntity.getMoney());
        request.setAttribute("json", json);
        request.getRequestDispatcher("/commit").forward(request, response);
    }

    @RequestMapping(value = "commit")
    public ModelAndView toCommit(HttpServletRequest request) {
        String json = (String) request.getAttribute("json");
        String orderNum = (String) request.getAttribute("orderNum");
        String amount = (String) request.getAttribute("amount");
        Map<String, String> reqMap = (Map) JSON.parse(json);

        StringBuffer sbHtml = new StringBuffer();
        List<String> keys = new ArrayList<>(reqMap.keySet());

        sbHtml.append("<form id=\"onlineForm\" name=\"onlineForm\" action=\"").append(url).append("\" method=\"post\">");
        String name;
        String value;
        for (int i = 0; i < keys.size(); i++) {
            name = keys.get(i);
            value = reqMap.get(name);
            if (value != null && !"".equals(value)) {
                sbHtml.append("<input type=\"hidden\" name=\"").append(name).append("\" value=\"" + value + "\"/>");
            }
        }
        sbHtml.append("<input type=\"submit\" value=\"确认付款\"></form>");
        System.out.println("sbHtml:" + sbHtml.toString());

        String ss = sbHtml.toString();
        ModelAndView modelAndView = new ModelAndView("commit");
        modelAndView.addObject("formStr", ss);
        modelAndView.addObject("orderNum", orderNum);
        modelAndView.addObject("amount", amount);
        return modelAndView;

    }



    @RequestMapping(value = "callback")
    @ResponseBody
    public String callback(HttpServletRequest request){
        System.out.println("订单号="+request.getParameter("mer_order"));
        System.out.println("订单金额="+request.getParameter("amount"));
        System.out.println("支付状态="+request.getParameter("status"));

        //验证签名.....

        // 业务处理完成 ，返回"success"

        return "success";
    }


}