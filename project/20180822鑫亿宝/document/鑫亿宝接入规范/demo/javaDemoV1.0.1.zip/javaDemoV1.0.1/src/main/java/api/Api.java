package api;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.SortedMap;
import java.util.TreeMap;

import org.joda.time.DateTime;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.xyb.utils.HttpClient;
import com.xyb.utils.MsgUtil;
import com.xyb.utils.HttpClient.HttpResult;

public class Api {
	private static final String MD5_KEY = "df04d65dada1468ca57a67c047653053";
	private static final String MERCHANT_CODE = "1033000000100001";
	private static final String CONTEXT_URL = "https://47.92.34.10/payGateway";
//	private static final String MD5_KEY = "sdfsdfsddfasjhyuhjhj";
	public static final String PAYMENT_QR_CODE_URL = "/payment/qrCode/v2";
	public static final String PAYMENT_H5_URL = "/payment/h5/v2";
	public static final String PAYMENT_GATEWAY_URL = "/payment/gateway/v2";
	public static final String PAYMENT_QUICK_URL = "/payment/quickPay/v2";
	
	public static final String ADVANCE_PAY_URL = "/advancePay/v2";
	public static final String QUERY_ORDER_URL = "/order/query/v2";
	private static final Charset CHARSET = Charset.forName("UTF-8");
	
	/**
	 * 扫码测试
	 * 
	 * @throws IOException
	 */
	@Test
	public void scanQRCode() {
		SortedMap<String, Object> paramMap = new TreeMap<String, Object>();
		paramMap.put("mchntOrderNo", new DateTime().toString("yyMMddHHmmSSS"));
		// 单位：分
		paramMap.put("orderAmount", 1000L);
		paramMap.put("clientIp", "127.0.0.1");
		paramMap.put("subject", "测试物品");
		paramMap.put("body", "惠动手机支付");
		paramMap.put("notifyUrl", "http://localhost:8080/payCenter-api/pc/Pay/Notify");
		paramMap.put("pageUrl", "http://baidu.com");
		paramMap.put("orderTime", new DateTime().toString("yyyyMMddHHmmss"));
		paramMap.put("orderExpireTime", new DateTime().plusMinutes(5).toString("yyyyMMddHHmmss"));
		paramMap.put("description", "描述信息");
		// 参考文档中的渠道编号表
		paramMap.put("channelCode", "qq_wallet_qr");
		paramMap.put("mchntCode", MERCHANT_CODE);
		paramMap.put("ts", new DateTime().toString("yyyyMMddHHmmssSSS"));
		paramMap.put("sign", MsgUtil.sign(paramMap, MD5_KEY));
		String jsonStr = JSON.toJSONString(paramMap);
		System.out.println("请求报文：" + jsonStr);
		// 发送报文
		try {
			HttpResult hr = HttpClient.doPostJson(CONTEXT_URL + PAYMENT_QR_CODE_URL,
					jsonStr, null, CHARSET);
			String retData = hr.getData();
			System.out.println(retData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 网关测试
	 * 
	 * @throws IOException
	 */
	@Test
	public void gatewayPay() {
		SortedMap<String, Object> paramMap = new TreeMap<String, Object>();
		paramMap.put("mchntOrderNo", new DateTime().toString("yyMMddHHmmSSS"));
		// 单位：分
		paramMap.put("orderAmount", 1000L);
		paramMap.put("clientIp", "127.0.0.1");
		paramMap.put("subject", "测试物品");
		paramMap.put("body", "惠动手机支付");
		paramMap.put("notifyUrl", "http://localhost:8080/payCenter-api/pc/Pay/Notify");
		paramMap.put("pageUrl", "http://baidu.com");
		paramMap.put("orderTime", new DateTime().toString("yyyyMMddHHmmss"));
		paramMap.put("orderExpireTime", new DateTime().plusMinutes(5).toString("yyyyMMddHHmmss"));
		paramMap.put("description", "描述信息");
//		paramMap.put("bankCode", "CEB"); // 输入银行代码，则直接跳转到银行的支付页面。不输入代码则跳转到收银台页面
		// 参考文档中的渠道编号表
		paramMap.put("channelCode", "gateway_pay");
		paramMap.put("mchntCode", MERCHANT_CODE);
		paramMap.put("ts", new DateTime().toString("yyyyMMddHHmmssSSS"));
		paramMap.put("sign", MsgUtil.sign(paramMap, MD5_KEY));
		String jsonStr = JSON.toJSONString(paramMap);
		System.out.println("请求报文：" + jsonStr);
		// 发送报文
		try {
			HttpResult hr = HttpClient.doPostJson(CONTEXT_URL + PAYMENT_GATEWAY_URL,
					jsonStr, null, CHARSET);
			String retData = hr.getData();
			System.out.println(retData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 快捷测试
	 * 
	 * @throws IOException
	 */
	@Test
	public void quickPay() {
		SortedMap<String, Object> paramMap = new TreeMap<String, Object>();
		paramMap.put("mchntOrderNo", new DateTime().toString("yyMMddHHmmSSS"));
		// 单位：分
		paramMap.put("orderAmount", 2000L);
		paramMap.put("clientIp", "127.0.0.1");
		paramMap.put("subject", "测试物品");
		paramMap.put("body", "惠动手机支付");
		paramMap.put("notifyUrl", "http://localhost:8080/payCenter-api/pc/Pay/Notify");
		paramMap.put("pageUrl", "http://baidu.com");
		paramMap.put("orderTime", new DateTime().toString("yyyyMMddHHmmss"));
		paramMap.put("orderExpireTime", new DateTime().plusMinutes(5).toString("yyyyMMddHHmmss"));
		paramMap.put("description", "描述信息");
		// 参考文档中的渠道编号表
		paramMap.put("channelCode", "quick_pay");
		paramMap.put("mchntCode", MERCHANT_CODE);
		paramMap.put("ts", new DateTime().toString("yyyyMMddHHmmssSSS"));
		paramMap.put("sign", MsgUtil.sign(paramMap, MD5_KEY));
		String jsonStr = JSON.toJSONString(paramMap);
		System.out.println("请求报文：" + jsonStr);
		// 发送报文
		try {
			HttpResult hr = HttpClient.doPostJson(CONTEXT_URL + PAYMENT_QUICK_URL,
					jsonStr, null, CHARSET);
			String retData = hr.getData();
			System.out.println(retData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * H5测试
	 * 
	 * @throws IOException
	 */
	@Test
	public void h5() {
		SortedMap<String, Object> paramMap = new TreeMap<String, Object>();
		paramMap.put("mchntOrderNo", new DateTime().toString("yyMMddHHmmSSS"));
		// 单位：分
		paramMap.put("orderAmount", 100L);
		paramMap.put("clientIp", "127.0.0.1");
		paramMap.put("subject", "测试物品");
		paramMap.put("body", "惠动手机支付");
		paramMap.put("notifyUrl", "http://localhost:8080/payCenter-api/pc/Pay/Notify");
		paramMap.put("pageUrl", "http://baidu.com");
		paramMap.put("orderTime", new DateTime().toString("yyyyMMddHHmmss"));
		paramMap.put("orderExpireTime", new DateTime().plusMinutes(5).toString("yyyyMMddHHmmss"));
		paramMap.put("description", "描述信息");
		// 参考文档中的渠道编号表
		paramMap.put("channelCode", "qq_wallet_h5");
		paramMap.put("mchntCode", MERCHANT_CODE);
		paramMap.put("ts", new DateTime().toString("yyyyMMddHHmmssSSS"));
		paramMap.put("sign", MsgUtil.sign(paramMap, MD5_KEY));
		String jsonStr = JSON.toJSONString(paramMap);
		System.out.println("请求报文：" + jsonStr);
		// 发送报文
		try {
			HttpResult hr = HttpClient.doPostJson(CONTEXT_URL + PAYMENT_H5_URL,
					jsonStr, null, CHARSET);
			String retData = hr.getData();
			System.out.println(retData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 代付测试
	 * @throws Exception 
	 */
	@Test
	public void advancePayV2() { 
		// 组装业务数据
		SortedMap<String, Object> paramMap = new TreeMap<String, Object>();
		// 参考文档中的渠道编号表
		paramMap.put("channelCode", "rt_ap");
		paramMap.put("mchntCode", MERCHANT_CODE);
		paramMap.put("mchntOrderNo", new DateTime().toString("yyMMddHHmmSSS"));
		// 单位：分
		paramMap.put("orderAmount", 1000L);
		paramMap.put("accountName", "xxx");
		paramMap.put("accountNo", "6224444331699914");
		paramMap.put("phone", "13011111110");
		paramMap.put("bankName", "光大银行");
		paramMap.put("orderSummary", "测试物品");
		paramMap.put("bankCode", "CEB");
		// 1-对公；2-对私
		paramMap.put("accountType", 1);
		paramMap.put("ts", new DateTime().toString("yyyyMMddHHmmssSSS"));
		paramMap.put("orderTime", new DateTime().toString("yyyyMMddHHmmss"));
		paramMap.put("sign", MsgUtil.sign(paramMap, MD5_KEY));
		
		String jsonStr = JSON.toJSONString(paramMap);
		System.out.println(jsonStr);
		// 发送报文
		try {
			HttpResult hr = HttpClient.doPostJson(CONTEXT_URL + ADVANCE_PAY_URL,
					jsonStr, null, CHARSET);
			// 响应结果分析
			String retData = hr.getData();
			System.out.println(retData);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	/**
	 * 订单查询测试
	 * @throws Exception 
	 */
	@Test
	public void queryV2() { 
		// 组装业务数据
		SortedMap<String, Object> paramMap = new TreeMap<String, Object>();
//		paramMap.put("mchntOrderNo", "20180321171256605");
		paramMap.put("sysOrderNo", "TT026518037799701083401");

		paramMap.put("channelCode", "rt_ap");
		paramMap.put("mchntCode", MERCHANT_CODE);
		paramMap.put("ts", new DateTime().toString("yyyyMMddHHmmssSSS"));
		paramMap.put("sign", MsgUtil.sign(paramMap, MD5_KEY));
		
		String jsonStr = JSON.toJSONString(paramMap);
		
		// 发送报文
		try {
			HttpResult hr = HttpClient.doPostJson(CONTEXT_URL + QUERY_ORDER_URL,
					jsonStr, CHARSET);
			// 响应结果分析
			String retData = hr.getData();
			System.out.println(retData);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
