package com.xyb.utils;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;

import org.apache.commons.codec.digest.DigestUtils;


/**
 * 平台消息处理工具类
 * 
 * @author zcy
 * @date 2016年12月24日 下午3:09:37
 */
public class MsgUtil {
	private static final String SIGNATURE_RCV = "sign";
	private static final Charset CHARSET_UTF8 = Charset.forName("utf-8");

	/**
	 * md5加密
	 *
	 * @param text
	 * @param charset
	 * @return
	 */
	private static String md5(String text, Charset charset) {
		byte[] bs = text.getBytes(charset);
		String signature = DigestUtils.md5Hex(bs);
		return signature;
	}

	/**
	 * 签名
	 *
	 * @param paramMap 有序集合，按照key的ASII值从小到大排序
	 * @param md5Key 密钥
	 * @return
	 */
	public static String sign(SortedMap<String, Object> paramMap, String md5Key) {
		StringBuilder stringBuilder = new StringBuilder();
		Iterator<Map.Entry<String, Object>> iter = paramMap.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<String, Object> entry = iter.next();
			String key = entry.getKey();
			if ((!key.equals(SIGNATURE_RCV))) {
				String value = String.valueOf(entry.getValue());
				if ((null != value) && (!"".equals(value))) {
					stringBuilder.append(key + "=" + value);
				}
			}
			
			if (iter.hasNext()) {
				stringBuilder.append("&");
			}
		}
		stringBuilder.append(md5Key);
		String buildString = stringBuilder.toString();
		return md5(buildString, CHARSET_UTF8).toUpperCase();
	}

	/**
	 * 验证签名
	 *
	 * @param paramMap
	 * @param md5Key
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static boolean verifySign(SortedMap<String, Object> paramMap, String md5Key)
			throws UnsupportedEncodingException {
		String respSignature = (String) paramMap.get(SIGNATURE_RCV);
		String signature = sign(paramMap, md5Key);
		if (respSignature.equals(signature)) {
			return true;
		}
		return false;
	}
}
