爱换购demo说明：本demo用户爱换购支付平台对下游渠道商开放支付相关渠道

项目结构
src:源代码
	-com.ibuy.demo:相关demo
		-Payment：支付
		-PayQuery：订单查询
		-ProxyPay：代付
		-ProxyPayQuery：代付查询
		-QuickPay：快捷支付
		
lib：依赖jar包（不再详细说明）

pay_config.properties：配置文件

readme:项目说明

