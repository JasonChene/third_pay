<?php
// 数据库配置
return array(
	'DB_TYPE'   => 'mysqli',       // 数据库类型
	'DB_HOST'   => '172.19.0.9',       // 服务器地址
	'DB_NAME'   => 'pay',       // 数据库名
	'DB_USER'   => 'root',       // 用户名
	'DB_PWD'    => '!Hacker!@#$%^&*()1111',        // 密码
	'DB_PORT'   => '3306',       // 端口
	'DB_PREFIX' => 'pay_',     // 数据库表前缀
);

