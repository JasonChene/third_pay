<?php
$parter="800001806";
$key="e5271f667c00368dac8807be4f38e2a5";
$submit_url="http://pay.gwwub.com/paybank.aspx";
$callbackurl="http://".$_SERVER['HTTP_HOST']."/payReturn.php";
$hrefbackurl="http://".$_SERVER['HTTP_HOST']."/payReturn.php";
?>