<?php

$p1_MerId			= "XXXX";	#在此輸入商號
$merchantKey	= "XXXXXXXXXXXXXXXXXXXXX";	#在此輸入安全碼

$privatekey = "XXXXXXXXXXXXXXXXXXXXX"; #在此輸入商戶私匙檔案位置
$publickey = "XXXXXXXXXXXXXXXXXXXXX"; #在此輸入平台公匙檔案位置 (在商戶後台下載)
$logName	= "Bank.log";

?>
