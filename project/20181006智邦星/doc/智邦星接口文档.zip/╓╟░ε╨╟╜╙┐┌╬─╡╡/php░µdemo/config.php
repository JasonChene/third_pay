<?php
	$payUrl="http://www.zbxpay.com/pay";//支付提交地址
	$queryUrl="http://www.zbxpay.com/query";//查询提交地址
	
	$merchant = "866001";//商户号
	$key = "53021e2cae854d2e8fd32e2e89e5ec1c";//商户密钥
	
	$notifyUrl="http://demo.zbxzf.com/notifyUrl.php";//异步回调
	$returnUrl="http://demo.zbxzf.com/returnUrl.php";//同步回调
	
?>