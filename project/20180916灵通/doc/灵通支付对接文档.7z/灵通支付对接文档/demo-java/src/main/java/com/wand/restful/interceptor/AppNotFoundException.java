package com.wand.restful.interceptor;

public class AppNotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;

}
