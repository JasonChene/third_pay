package com.yijie.demo.controller;


import com.yijie.demo.util.HttpUtil;
import com.yijie.demo.util.RSAUtil;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;


@Controller
@RequestMapping("test")
public class PayTestController {


    /***平台公钥:商户后台进行下载或者跟客服索要***/
    public static String PLATFORM_PUBLICKEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDF0yWcQWN1ADT6yuV3p6oxen5drNq3Jq/8gS+kS3V2gsodiVGxcONp9I58Ni0Lb0nPuTihY5bTyGkSyLNPgy1cil3krECwQ3aaxkr659V4b15dw7TbgcHCOjynWgU0FPGA0XOMSc8NdBhoF7eH7eQKDgmaeIHiaWwlrr83ccfZhQIDAQAB" ;
    /****商户私钥:商户自行生成一对密钥，并将其对应的公钥提交到平台****/
    public static String MERCHANT_PRIVATEKEY_80061 = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALR4Kb3tw0JZ/qPE\n" +
			"qFmAPE/65ZwJnnFYadyaAnzfow3ywX6xU0DFd21oNlJ7BM5PDrLb76EwVEtvjvGC\n" +
			"G8jAmhMV/Pf2UkulWW1dEcbcwaCLdiZ6F9JSm9vcqvHyGcGFOuNv7xRbJRRW5NRw\n" +
			"WOBOY41wJybQtpH+x591SuuqI4bdAgMBAAECgYBcT/byGxO89fHF7Ys7tNelBa67\n" +
			"gUQVsGb+G51YKMDsGpeVabkvMZLkWOEokZqkuVXIca4CookLyTWyHZ5+st5cNjh1\n" +
			"fSA5lvflr1AYF4agqB+6Y8EtrAIi10TvcfthixWJG9k16ssCSqvpdT378elol5Qi\n" +
			"pqzh4cWF9cvJjh2sVQJBAOoqFc0cnJxC2vkuAGp+gb+ERVAoM2AYcULb5chNbdRR\n" +
			"O55ZHFy1ep5IpZG3A0Ad3NH44IWxyRkhMymCopoFkVsCQQDFTEirZlaeOeqbIlx6\n" +
			"E5bKqLHQQ2nZVk0Dg/10tsmv/POduzDot9llqQy3xDn+SzruX82ww5RkDBFJ8aJ2\n" +
			"+sYnAkBRLNu36iZEaUy9uvu77zUNbk4U9oqw0mhZFB/5KxZa1vpC74NMhEEIpAh5\n" +
			"licTUAbf51X2IuaixoaU6ktx92InAkBB7TKfK2woJPwy6HF0TVVm1KXODKiy+fZ0\n" +
			"BUfNF0MfrmuNOj6mlMBtCub4BPbH9UV038hwl3nfUHT6e2apUTSjAkB1c9ERoSyp\n" +
			"sV19osZYhkPyJHva1Ma4DylpYYdO/Km+GS4KyKcdcYzux/GBNLjkrGox2rhT9rYy\n" +
			"+Wyr686+ef7z" ;

	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

	private static final Logger log = LoggerFactory.getLogger(PayTestController.class);
	private static final String PAYURL = "http://58.82.232.169/gateway/payin/pay";
	private static final String TRANSURL = "http://58.82.232.169/gateway/tran/transfer";
	private static final String QUERYURL = "http://58.82.232.169/merchant/customer/query";
	private static final String VERSION = "V2.1";


	@RequestMapping("toTestPay")
    public String toTestPay(Model model) {
		model.addAttribute("merOrderNo", sdf.format(new Date()));
        return "test/pay_test";
    }

	@RequestMapping("toTestTran")
	public String toTestTran(Model model) {
		model.addAttribute("merOrderNo", sdf.format(new Date()));
		return "test/tran_test";
	}

	/**
	 * @Description: 交易请求
	 * @MethodName: testPay
	 * @Params: [request]
	 * @Return: java.lang.Object
	 * @Date: 2018-10-10 17:01
	 * @Author: Di Zhang
	 */
    @RequestMapping("testPay")
	@ResponseBody
    public Object testPay(HttpServletRequest request) throws Exception {
		//1.获取页面参数
        String merNo = request.getParameter("merNo");
        String payType = request.getParameter("payType");
        String orderAmount = request.getParameter("orderAmount");
        String orderNo = request.getParameter("orderNo");
        String webSite = request.getParameter("webSite");
        String email = request.getParameter("email");
        String notifyUrl = request.getParameter("notifyUrl");
        String returnUrl = request.getParameter("returnUrl");
        String bankCode = request.getParameter("bankCode");
        String ip = request.getParameter("ip");
        String goodsInfo = request.getParameter("goodsInfo");

        //2.组装请求业务数据
        JSONObject paramJson = new JSONObject();
        paramJson.put("orderAmount", orderAmount);
        paramJson.put("payType", payType);
        //paranmJson.put("bankCode" ,"ABC") ;
        paramJson.put("notifyUrl", notifyUrl);
        paramJson.put("returnUrl", returnUrl);
        paramJson.put("orderNo", orderNo);
        paramJson.put("bankCode", bankCode);
        paramJson.put("email", email);
        paramJson.put("ip", ip);
        paramJson.put("webSite", webSite);
        paramJson.put("goodsInfo", goodsInfo);
		//3.发送请求 处理返回信息
		return sendRequest(merNo, paramJson,null,PAYURL);
	}




	/**
	 * @Description: 代付测试 [测试号未开通代付权限]
	 * @MethodName: testTran
	 * @Params: [request]
	 * @Return: java.lang.Object
	 * @Date: 2018-10-10 17:08
	 * @Author: Di Zhang
	 */
    @RequestMapping("testTran")
	@ResponseBody
    public Object testTran(HttpServletRequest request) throws Exception {
		//1.获取页面参数
        String merNo = request.getParameter("merNo");
        String accountNo = request.getParameter("accountNo");
        String bankCode = request.getParameter("bankCode");
        String tranAmount = request.getParameter("tranAmount");
        String orderNo = request.getParameter("orderNo");
        String certNo = request.getParameter("certNo");
        String accUserName = request.getParameter("accUserName");
        String notifyUrl = request.getParameter("notifyUrl");
        String accProvince = request.getParameter("accProvince");
        String accCity = request.getParameter("accCity");
        String phone = request.getParameter("phone");
		//2.组装请求业务数据
        JSONObject paramJson = new JSONObject();
        paramJson.put("accountNo", accountNo);
        paramJson.put("bankCode", bankCode);
        paramJson.put("tranAmount", tranAmount);
        paramJson.put("orderNo", orderNo);
        paramJson.put("certNo", certNo);
        paramJson.put("notifyUrl", notifyUrl);
        paramJson.put("accUserName", accUserName);
        paramJson.put("accProvince", accProvince);
        paramJson.put("accCity", accCity);
        paramJson.put("phone", phone);
		//3.发送请求 处理返回信息
		return sendRequest(merNo, paramJson,null,TRANSURL);
    }

	/**
	 * @Description: 订单查询
	 * @MethodName: testQuery
	 * @Params: []
	 * @Return: java.lang.Object
	 * @Date: 2018-10-10 17:29
	 * @Author: Di Zhang
	 */
	@RequestMapping("testQuery")
	@ResponseBody
	public Object testQuery() throws Exception {

		//1.组装请求业务数据
		JSONObject paramJson = new JSONObject();
		paramJson.put("orderNo", "20181010171844594");
		//2.发送请求 处理返回信息
		return sendRequest("80061", paramJson,"payQuery",QUERYURL);
	}

	/**
	 * @Description: 异步通知
	 * @MethodName: testNotify
	 * @Params: [request]
	 * @Return: java.lang.Object
	 * @Date: 2018-10-10 17:51
	 * @Author: Di Zhang
	 */
	public Object testNotify(HttpServletRequest request) throws Exception {

		String reqStr = HttpUtil.getTextFromRequestInStream(request);
		log.info("本次回调返回参数:{}",reqStr);
		if (StringUtils.isBlank(reqStr)) {
			return null;
		}
		JSONObject json = JSONObject.parseObject(reqStr);
		String retCode = json.getString("retCode");
		if (!"1".equals(retCode)) {
			log.info("本次回调retCode不为1");
			return json;
		}

		String payDataStr = json.getString("payData");
		//商户私钥解密payData
		String encryptPayData = RSAUtil.decryptByPrivateKey(payDataStr, MERCHANT_PRIVATEKEY_80061);
		JSONObject repJson = JSONObject.parseObject(encryptPayData);
		log.info("本次请求返回业务参数:{}",repJson);
		//平台公钥验签
		boolean flag = validateSign(repJson, PLATFORM_PUBLICKEY, repJson.getString("signInfo"));
		if (!flag) {
			log.info("验签失败");

		}
		//验签成功进行后续处理....

		//注:确认通知后需返回给平台 SUCCESS

		return json;

	}



	private Object sendRequest(String merNo, JSONObject paramJson,String serviceType,String url) throws Exception {
		//1.商户私钥签名
		String signInfo = createSignInfo(paramJson, MERCHANT_PRIVATEKEY_80061);
		paramJson.put("signInfo", signInfo);
		log.info("业务参数:{}",paramJson);

		//2.组装最终请求参数
		Map<String, String> postmap = new HashMap<>();
		postmap.put("merNo", merNo);

		//3.平台公钥加密payData
		String payData = RSAUtil.encryptByPublicKey(paramJson.toJSONString(), PLATFORM_PUBLICKEY);

		postmap.put("payData", payData);
		postmap.put("version", VERSION);

		//查询订单需要增加 serviceType 参数
		if ("payQuery".equalsIgnoreCase(serviceType) || "tranQuery".equalsIgnoreCase(serviceType)) {
			postmap.put("serviceType", serviceType);
		}

		log.info("最终请求参数:{}",postmap);
		String resultStr;

		try{
			resultStr = HttpUtil.sendIgnoreVerifySSL(url, postmap, "utf-8");
		}catch(Exception e){
			return null;
		}
		if (StringUtils.isBlank(resultStr)) {
			return null;
		}
		//4.解析返回信息
		log.info("本次请求返回参数:{}",resultStr);
		JSONObject json = JSONObject.parseObject(resultStr);
		String retCode = json.getString("retCode");
		if (!"1".equals(retCode)) {
			log.info("本次请求返回retCode不为1");
			return json;
		}
		String payDataStr = json.getString("payData");
		//5.商户私钥解密payData
		String encryptPayData = RSAUtil.decryptByPrivateKey(payDataStr, MERCHANT_PRIVATEKEY_80061);
		JSONObject repJson = JSONObject.parseObject(encryptPayData);
		log.info("本次请求返回业务参数:{}",repJson);
		//6.平台公钥验签
		boolean flag = validateSign(repJson, PLATFORM_PUBLICKEY, repJson.getString("signInfo"));
		if (!flag) {
			log.info("验签失败");

		}
		//7.验签成功进行后续处理....

		/*需要注意的是: 当支付方式为扫码时,平台会返回url或imgUrl
		url:二维码链接,可用于生成二维码(imgUrl,url只会返回其中一个)
		imgUrl:二维码图片地址,直接访问即可(imgUrl,url只会返回其中一个)
		此处需要判断*/

		return json;
	}


	private static String createSignInfo(JSONObject json, String privateKey) {

		Set<String> keySet = json.keySet();
		TreeSet<String> treeSet = new TreeSet<>(keySet);
		StringBuffer plainString = new StringBuffer();
		/**param1=value1&param2=value2&param3=value3*/
		for (String key : treeSet) {
			if ("signInfo".equalsIgnoreCase(key)) {
				continue;
			}
			if (StringUtils.isEmpty(json.getString(key))) {
				continue;
			}
			plainString.append(key + "=" + json.getString(key) + "&");
		}
		String plainSign = plainString.substring(0, plainString.length() - 1);

		log.info("签名原串：" + plainSign);

		privateKey = privateKey.replace("\r\n", "");
		privateKey = privateKey.replace(" ", "");

		String signInfo = null;
		try {
			/* **rsa + md5****/
			signInfo = RSAUtil.signByPrivateKey(plainSign, privateKey);
		} catch (Exception e) {
			log.info(e.getMessage());
			log.info("生成签名错误");
			return null;
		}
		return signInfo;
	}

	public static boolean validateSign(JSONObject json, String publicKey, String merSignInfo) {

		Set<String> keySet = json.keySet();
		TreeSet<String> treeSet = new TreeSet<>(keySet);
		StringBuffer plainString = new StringBuffer();
		/**param1=value1&param2=value2&param3=value3*/
		for (String key : treeSet) {
			if ("signInfo".equalsIgnoreCase(key)) {
				continue;
			}
			if (StringUtils.isEmpty(json.getString(key))) {
				continue;
			}
			plainString.append(key + "=" + json.getString(key) + "&");
		}
		String plainSign = plainString.substring(0, plainString.length() - 1);
		log.info("签名原串:" + plainSign);
		/*  String merSign = json.getString("signInfo") ;*/
		publicKey = publicKey.replace("\r\n", "");
		publicKey = publicKey.replace(" ", "");

		boolean passed = false;
		try {
			/* **rsa + md5****/
			passed = RSAUtil.validateSignByPublicKey(plainSign, publicKey, merSignInfo);

		} catch ( Exception e ) {
			log.error(e.getMessage());
			return false;
		}
		return passed;
	}

}
