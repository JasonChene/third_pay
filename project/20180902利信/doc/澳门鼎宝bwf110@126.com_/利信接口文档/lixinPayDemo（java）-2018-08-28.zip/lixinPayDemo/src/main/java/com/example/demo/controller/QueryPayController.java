package com.example.demo.controller;

import com.example.demo.bean.lixin.QueryOrderResponseBean;
import com.example.demo.service.QRPayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class QueryPayController {

    @Autowired
    private QRPayService qrPayService;


    @RequestMapping(value = "/pay/query", method = RequestMethod.POST)
    public QueryOrderResponseBean query(String tradeNo) throws IOException {
        return qrPayService.queryOrder(tradeNo);
    }
}
