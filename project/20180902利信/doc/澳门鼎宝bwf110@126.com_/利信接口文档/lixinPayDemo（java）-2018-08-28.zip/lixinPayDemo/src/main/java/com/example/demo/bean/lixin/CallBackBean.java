package com.example.demo.bean.lixin;

import com.alibaba.fastjson.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class CallBackBean {

    private String tradeNo;
    private String platformOrderId;
    private int amount;
    private String status;
    private int code;
    private String msg;
    private long date;
    private String sign;

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getPlatformOrderId() {
        return platformOrderId;
    }

    public void setPlatformOrderId(String platformOrderId) {
        this.platformOrderId = platformOrderId;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public Map toMap() {
        Map<String, Object> params = new HashMap<>(13);
        params.put("tradeNo",this.tradeNo);
        params.put("platformOrderId",this.platformOrderId);
        params.put("amount",this.amount);
        params.put("status",this.status);
        params.put("code",this.code);
        params.put("msg",this.msg);
        params.put("date",this.date);
        return params;
    }

    @Override
    public String toString(){
        Map<String, Object> sortMap = new TreeMap<>();
        sortMap.putAll(this.toMap());
        return JSONObject.toJSONString(sortMap);
    }
}
