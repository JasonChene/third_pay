package com.example.demo.bean.lixin;

import com.alibaba.fastjson.JSONObject;
import com.example.demo.util.StringUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class WxAndAliPayRequestBean {

    private String tradeNo;
    private String merchantNo;
    private String operationCode;
    private String version;
    private long date;
    private String sign;
    private long amount;
    private String subject;
    private String body;
    private String paymentType;
    private String notifyUrl;
    private String frontUrl;
    private String spbillCreateIp;

    public WxAndAliPayRequestBean(){}

    public WxAndAliPayRequestBean(String tradeNo, String merchantNo, String operationCode, String version, long date, String sign, int amount, String subject, String body, String paymentType, String notifyUrl, String frontUrl, String spbillCreateIp) {
        this.tradeNo = tradeNo;
        this.merchantNo = merchantNo;
        this.operationCode = operationCode;
        this.version = version;
        this.date = date;
        this.sign = sign;
        this.amount = amount;
        this.subject = subject;
        this.body = body;
        this.paymentType = paymentType;
        this.notifyUrl = notifyUrl;
        this.frontUrl = frontUrl;
        this.spbillCreateIp = spbillCreateIp;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getOperationCode() {
        return operationCode;
    }

    public void setOperationCode(String operationCode) {
        this.operationCode = operationCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getFrontUrl() {
        return frontUrl;
    }

    public void setFrontUrl(String frontUrl) {
        this.frontUrl = frontUrl;
    }

    public String getSpbillCreateIp() {
        return spbillCreateIp;
    }

    public void setSpbillCreateIp(String spbillCreateIp) {
        this.spbillCreateIp = spbillCreateIp;
    }

    public Map toMap() {
        Map<String, Object> params = new HashMap<>(13);
        params.put("tradeNo",this.tradeNo);
        params.put("merchantNo",this.merchantNo);
        params.put("operationCode",this.operationCode);
        params.put("version",this.version);
        params.put("date",this.date);
        params.put("amount",this.amount);
        params.put("subject",this.subject);
        params.put("body",this.body);
        params.put("paymentType",this.paymentType);
        params.put("notifyUrl",this.notifyUrl);
        params.put("frontUrl",this.frontUrl);
        params.put("spbillCreateIp",this.spbillCreateIp);
        return params;
    }

    public String toJSONString(){
        Map<String,Object> map = this.toMap();
        map.put("sign",this.sign);
        Map<String, Object> sortMap = new TreeMap<>();
        sortMap.putAll(map);
        return JSONObject.toJSONString(sortMap);
    }

    public String toKeyValueString(){
        Map<String,Object> map = this.toMap();
        map.put("sign",this.sign);
        return StringUtil.sort(map,"");
    }
}
