package com.example.demo.util;

/**
 * Created by Administrator on 2017/11/25.
 */
public class Md5Signature {
    //MD5验证签名
    public static boolean doCheck(String content, String sign) {
        String md5 = MD5.MD5Encode(content);
        md5 = md5.toUpperCase();
        if (md5.equals(sign)) {
            return true;
        } else {
            return false;
        }
    }

    public static String getSign(String content)
    {
        String s=MD5.MD5Encode(content);
        return  s.toUpperCase();
    }
}
