package com.example.demo.controller;

import com.example.demo.bean.lixin.BankPayRequestBean;
import com.example.demo.bean.lixin.CallBackBean;
import com.example.demo.service.QRPayService;
import com.example.demo.util.Md5Signature;
import com.example.demo.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class QRPayController {
    public static final String SUCCESS = "0";

    @Autowired
    private QRPayService qrPayService;

    @RequestMapping(value = "/pay/qr", method = RequestMethod.POST)
    public String qrPay(long amount, Model model) {
        model.addAttribute("payCode", qrPayService.qrPay(amount));
        return "QRPayResult";
    }

    @RequestMapping(value = "/pay/h5", method = RequestMethod.POST)
    public String h5Pay(long amount, Model model) {
        model.addAttribute("payCode", qrPayService.h5Pay(amount));
        return "H5PayResult";
    }

    @RequestMapping(value = "/pay/bankPay", method = RequestMethod.POST)
    public String bankPay(long amount, String paymentType, Model model) {
        BankPayRequestBean requestBean = qrPayService.bankPay(amount, paymentType);
        model.addAttribute("tradeNo", requestBean.getTradeNo());
        model.addAttribute("merchantNo", requestBean.getMerchantNo());
        model.addAttribute("operationCode", requestBean.getOperationCode());
        model.addAttribute("version", requestBean.getVersion());
        model.addAttribute("date", requestBean.getDate());
        model.addAttribute("sign", requestBean.getSign());
        model.addAttribute("amount", requestBean.getAmount());
        model.addAttribute("subject", requestBean.getSubject());
        model.addAttribute("body", requestBean.getBody());
        model.addAttribute("paymentType", requestBean.getPaymentType());
        model.addAttribute("notifyUrl", requestBean.getNotifyUrl());
        model.addAttribute("frontUrl", requestBean.getFrontUrl());
        model.addAttribute("spbillCreateIp", requestBean.getSpbillCreateIp());
        model.addAttribute("bankCode", requestBean.getBankCode());
        return "BankPayResult";
    }

    @RequestMapping("/pay/notify")
    public String notifyUrl(CallBackBean callBackBean) {
        String content = StringUtil.sort(callBackBean.toMap(), "");
        // check sign
        boolean result = Md5Signature.doCheck(content, callBackBean.getSign());
        if (result) {
            // Handle only successful businesses
            if (SUCCESS.equals(callBackBean.getStatus())
            && QRPayService.SUCCESS.equals(callBackBean.getCode())) {

                // todo coding your business
            }
        }

        return "success";
    }

    @RequestMapping("/pay/front")
    public String frontUrl(CallBackBean callBackBean) {
        String content = StringUtil.sort(callBackBean.toMap(), "");
        // check sign
        boolean result = Md5Signature.doCheck(content, callBackBean.getSign());
        if (result) {
            // Handle only successful businesses
            if (SUCCESS.equals(callBackBean.getStatus())
                    && QRPayService.SUCCESS.equals(callBackBean.getCode())) {

                // todo coding your business
            }
        }

        return "front";
    }
}
