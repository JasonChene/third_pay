package com.example.demo.service;

import com.alibaba.fastjson.JSONObject;
import com.example.demo.bean.lixin.*;
import com.example.demo.util.Md5Signature;
import com.example.demo.util.StringUtil;
import com.squareup.okhttp.*;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Map;

@Service
public class QRPayService {

    public static final String APP_KEY = "523850B2CD5944CB9255AD367F28739C";
    public static final String MERCHANT_NO = "1029256874471456768";
    public static final String SUCCESS = "100";
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    public String qrPay(long amount) {
        String s = null;
        WxAndAliPayRequestBean requestBean = requestBean(amount);
        Map<String, Object> map = requestBean.toMap();
        map.put("sign", requestBean.getSign());
        FormEncodingBuilder form = new FormEncodingBuilder();
        for (String key : map.keySet()) {
            form.add(key, map.get(key) + "");
        }

        OkHttpClient client = new OkHttpClient();
        Request request = new Request
                .Builder()
                .url("http://sh.lixinpay.cn:8080/api/payment/createOrder")
                .post(form.build())
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String resBody = response.body().string();
                System.out.println(resBody);
                WxAndAliPayResponseBean responseBean =
                        JSONObject.parseObject(resBody, WxAndAliPayResponseBean.class);
                if (SUCCESS.equals(responseBean.getCode())) {
                    String content = StringUtil.sort(responseBean.toMap(), APP_KEY);
                    boolean result = Md5Signature.doCheck(content, responseBean.getSign());
                    if (result) {
                        s = responseBean.getPayCode();
                    }
                }
            } else {
                throw new IOException("Unexpected code " + response);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return s;
    }

    public String h5Pay(long amount) {
        // H5支付  截取 扫码支付 响应的支付码 唤醒支付宝支付
        String s = null;
        WxAndAliPayRequestBean requestBean = requestBean(amount);
        Map<String, Object> map = requestBean.toMap();
        map.put("sign", requestBean.getSign());
        FormEncodingBuilder form = new FormEncodingBuilder();
        for (String key : map.keySet()) {
            form.add(key, map.get(key) + "");
        }

        OkHttpClient client = new OkHttpClient();
        Request request = new Request
                .Builder()
                .url("http://sh.lixinpay.cn:8080/api/payment/createOrder")
                .post(form.build())
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String resBody = response.body().string();
                System.out.println(resBody);
                WxAndAliPayResponseBean responseBean =
                        JSONObject.parseObject(resBody, WxAndAliPayResponseBean.class);
                if (SUCCESS.equals(responseBean.getCode())) {
                    String content = StringUtil.sort(responseBean.toMap(), APP_KEY);
                    boolean result = Md5Signature.doCheck(content, responseBean.getSign());
                    if (result) {
                        s = responseBean.getPayCode().split("text=")[1];
                    }
                }
            } else {
                throw new IOException("Unexpected code " + response);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return s;
    }

    /**
     * wangguan
     * @param amount
     * @return
     */
    public BankPayRequestBean bankPay(long amount, String paymentType) {
        return requestBean2(amount, paymentType);
    }

    /**
     * rder.query
     * @throws IOException
     */
    public QueryOrderResponseBean queryOrder(String tradeNo) throws IOException {
        QueryOrderRequestBean requestBean = new QueryOrderRequestBean();
        requestBean.setDate(System.currentTimeMillis());
        requestBean.setMerchantNo(MERCHANT_NO);
        requestBean.setTradeNo(tradeNo);
        requestBean.setVersion("1.0");
        requestBean.setOperationCode("order.query");
        requestBean.setNonceStr("自定义");

        String content = StringUtil.sort(requestBean.toMap(), APP_KEY);

        requestBean.setSign(Md5Signature.getSign(content));

        RequestBody body = RequestBody.create(JSON, requestBean.toString());
        OkHttpClient client = new OkHttpClient();
        Request request = new Request
                .Builder()
                .url("http://sh.lixinpay.cn:8080/api/payment/queryOrder")
                .post(body)
                .build();
        Response response = client.newCall(request).execute();

        if (response.isSuccessful()) {
            QueryOrderResponseBean responseBean = JSONObject.parseObject(response.body().string(),QueryOrderResponseBean.class);

            System.out.println(responseBean.toString());
            // response body data code is not 100
            // nothing to do
            if ( SUCCESS.equals(responseBean.getCode())){
                String text = StringUtil.sort(responseBean.toMap(), APP_KEY);
                // check sign
                boolean result =
                        Md5Signature.doCheck(text,responseBean.getSign());
                if (result){
                    // todo coding your business
                }
                return responseBean;
            }
        } else {
            throw new IOException("Unexpected code " + response);
        }
        return null;
    }

    private WxAndAliPayRequestBean requestBean(long amount) {
        WxAndAliPayRequestBean requestBean = new WxAndAliPayRequestBean();
        requestBean.setDate(System.currentTimeMillis());
        requestBean.setMerchantNo(MERCHANT_NO);
        requestBean.setTradeNo(System.currentTimeMillis() + "");
        requestBean.setVersion("1.0");
        requestBean.setAmount(amount);
        requestBean.setSubject("mingcheng");
        requestBean.setBody("miaoshu");
        requestBean.setNotifyUrl("http://127.0.0.1:8080/pay/notify");
        requestBean.setFrontUrl("http://127.0.0.1/pay/front");
        requestBean.setSpbillCreateIp("127.0.0.1");
        requestBean.setOperationCode("order.createOrder");
        requestBean.setPaymentType("WEIXIN_QRCODE");

        String content = StringUtil.sort(requestBean.toMap(), APP_KEY);

        requestBean.setSign(Md5Signature.getSign(content));

        return requestBean;
    }


    private BankPayRequestBean requestBean2(long amount, String paymentType) {
        BankPayRequestBean requestBean = new BankPayRequestBean();
        requestBean.setDate(System.currentTimeMillis());
        requestBean.setMerchantNo(MERCHANT_NO);
        requestBean.setTradeNo(System.currentTimeMillis() + "");
        requestBean.setVersion("1.0");
        requestBean.setAmount(amount);
        requestBean.setSubject("mingcheng");
        requestBean.setBody("miaoshu");
        requestBean.setNotifyUrl("http://127.0.0.1:8080/pay/notify");
        requestBean.setFrontUrl("http://127.0.0.1/pay/front");
        requestBean.setSpbillCreateIp("127.0.0.1");
        requestBean.setOperationCode("order.createOrder");
        requestBean.setPaymentType(paymentType);
        requestBean.setBankCode("01020000");

        String content = StringUtil.sort(requestBean.toMap(), APP_KEY);

        requestBean.setSign(Md5Signature.getSign(content));

        return requestBean;
    }
}
