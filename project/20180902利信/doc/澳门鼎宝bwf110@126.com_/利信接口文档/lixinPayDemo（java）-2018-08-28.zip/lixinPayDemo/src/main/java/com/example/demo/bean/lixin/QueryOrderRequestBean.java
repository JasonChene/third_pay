package com.example.demo.bean.lixin;

import com.alibaba.fastjson.JSONObject;
import com.example.demo.util.StringUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class QueryOrderRequestBean {

    private String date;
    private String merchantNo;
    private String nonceStr;
    private String operationCode = "order.query";
    private String version = "1.0";
    private String sign;
    private String tradeNo;

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getOperationCode() {
        return operationCode;
    }

    public void setOperationCode(String operationCode) {
        this.operationCode = operationCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = String.valueOf(date);
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }

    public Map toMap() {
        Map<String, Object> params = new HashMap<>(7);
        params.put("tradeNo",this.tradeNo);
        params.put("merchantNo",this.merchantNo);
        params.put("operationCode",this.operationCode);
        params.put("version",this.version);
        params.put("date",this.date);
        params.put("nonceStr",this.nonceStr);
        return params;
    }

    public String toJSONString(){
        Map<String,Object> map = this.toMap();
        map.put("sign",this.sign);
        Map<String, Object> sortMap = new TreeMap<>();
        sortMap.putAll(map);
        return JSONObject.toJSONString(sortMap);
    }

    public String toKeyValueString(){
        Map<String,Object> map = this.toMap();
        map.put("sign",this.sign);
        return StringUtil.sort(map,"");
    }
}
