package com.example.demo.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.TreeMap;

import static org.apache.logging.log4j.util.Strings.isBlank;

public class StringUtil extends StringUtils {

    /**
     * sort
     * @param params
     * @return
     */
    public static String sort(Map<String, Object> params,String appKey) {
        Map<String, Object> sortMap = new TreeMap<>();
        sortMap.putAll(params);
        // k1=v1&k2=v2...
        StringBuilder builder = new StringBuilder();
        if (!sortMap.isEmpty()) {
            for (Map.Entry<String, Object> s : sortMap.entrySet()) {
                String key = s.getKey();
                Object value = s.getValue();
                if (isBlank(String.valueOf(value))) {
                    continue;
                }
                builder.append(key).append("=").append(value).append("&");
            }
            if (appKey != null && !"".equals(appKey)) {
                builder.append("appkey").append("=").append(appKey);
            }else {
                builder.delete(builder.length() - 1, builder.length());
            }
        }
        return builder.toString();

    }
}
