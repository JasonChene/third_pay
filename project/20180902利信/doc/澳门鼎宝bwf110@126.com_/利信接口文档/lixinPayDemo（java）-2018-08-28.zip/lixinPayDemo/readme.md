spring boot 2.0.3 项目，请在 jdk 1.8+ 运行

**demo 运行方式 :**

启动 DemoApplication

访问首页： http://本机ip:8080

提供了 okhttp 和 HttpURLConnection 连接 支付系统的2种demo

分别为: QRPayService、 HttpURLConnections

请自行选择参考哪个demo

注意事项

银联支付：在测试页面可以选择支付类型，目前只支持网关支付；

h5 支付：实际调用的是支付系统的扫码支付接口，截取响应的支付码进行页面跳转，请仔细阅读h5支付demo源码；