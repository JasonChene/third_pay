package com.grep.pay;

import java.util.HashMap;
import java.util.Map;

import com.grep.util.DateUtil;
import com.grep.util.HttpClientHelperUtil;
import com.grep.util.SignUtil;

public class Demo {
	
	private static final String APPID = "";//APPID
	private static final String KEY = "";//签名密钥
	private static final String SCANURL = "http://34.248.37.237:8888/ts/scanpay/pay";
	
	public static void main(String[] args) {
		
		Demo demo = new Demo();
		
		//扫码
		//demo.scanPay();
		
		//支付订单查询
		//demo.queryPay();		
		
	}
	
	private void scanPay(){
		Map<String, Object> map = new HashMap<String, Object>();//TreeMap
		map.put("appid", APPID);//商户编码
		map.put("orderNo", "TEST"+DateUtil.getStringDate("yyyyMMddHHmmss"));//业务单号
		map.put("dateTime", DateUtil.getStringDate("yyyyMMddHHmmss"));
		map.put("amount", "3000");//支付金额
		map.put("payType", "SCANPAY_ALIPAY");//支付类型
		map.put("productName", "测试商品");//商品名称
		map.put("asynNotifyUrl", "http://www.baidu.com/notify");//异步地址
		map.put("paySm", "");//扩展字段
		String str=SignUtil.getSign(map, KEY);//密钥
		map.put("sign", str);
		
		String m = HttpClientHelperUtil.doPost(SCANURL, map, "utf-8");
	
		System.out.println(m);
	}
	
	public void queryPay(){
		
		Map<String, Object> map = new HashMap<String, Object>();//TreeMap
		map.put("appid", APPID);//商户编码
		map.put("orderNo", "TEST20180712170911");//商户订单号
		String str=SignUtil.getSign(map, KEY);//密钥
		map.put("sign", str);
		
		String m = HttpClientHelperUtil.doPost(QUERYPAYURL, map, "utf-8");
	
		System.out.println(m);

	}
}
