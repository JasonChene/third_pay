package com.grep.util;

import java.security.MessageDigest;

public class MD5Util {
	
	 private static final String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

	    public static String encode(String data,String enCode) {
	        try {
	            MessageDigest md5 = MessageDigest.getInstance("md5");
	            byte[] byteArray = md5.digest(data.getBytes());
	            String passwordMD5 = byteArrayToHexString(byteArray);
	            return passwordMD5;
	        } catch (Exception e) {
	        }
	        return data;
	    }

	    private static String byteArrayToHexString(byte[] byteArray) {
	        StringBuffer sb = new StringBuffer();
	        for (byte b : byteArray) {
	            sb.append(byteToHexChar(b));
	        }
	        return sb.toString();
	    }

	    private static Object byteToHexChar(byte b) {
	        int n = b;
	        if (n < 0) {
	            n = 256 + n;
	        }
	        int d1 = n / 16;
	        int d2 = n % 16;
	        return hex[d1] + hex[d2];
	    }

	    public static void main(String[] args) {
	    	String aString = "2016-09-23 17:22:51消费16160923172250200062016-09-23 17:22:510.015656567008801000012480测试成功2016-09-23 17:22:45http://101.200.166.227:8080/tfPayDemo/return_url.jsp565667222880100002345284A8251FECD84E599B7B1037579E6A4D商户消费141609231722451003314746225646380.01http://101.200.166.227:8080/tfPayDemo/notify_url.jsp90001001";
	    	String mmString = SignUtil.encode(aString, "GBK");
	    	System.out.println(SignUtil.signUtil(mmString, "12345678"));
	    	String md = SignUtil.encode("user1"+"user1pass"+"6ZaW8V"+"1476113775105", "utf-8");
			System.out.println(md);
		}
}
