package com.grep.util;

public class StringUtil {

	/**
	 * 去除JSON多余的引号及斜杠
	 * @param str json字符串
	 * @return
	 */
	public static String jsonToString(String str){
		return str.replace('"'+"{", "{").replace("}"+'"', "}").replace("\\", "");
	}
}
