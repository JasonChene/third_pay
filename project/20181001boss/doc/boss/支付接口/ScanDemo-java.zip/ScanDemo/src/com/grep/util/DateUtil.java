package com.grep.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	/**
	 * 判断时间相差5分钟左右
	 * @return
	 */
	public static Long judgeDate(String dateTimeStr){
		
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
    	Long date = 0L;
		try {
			Date dateTime = sdf.parse(dateTimeStr);
			Long dateTimeSec = dateTime.getTime() / 1000;
	    	long nowTime = System.currentTimeMillis()/1000;
	    	date = Math.abs(nowTime-dateTimeSec);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * 获取当前系统时间
	 * @param format 时间格式
	 * @return Date
	 */
	public static Date getDate(String format){
		
		SimpleDateFormat sdf=new SimpleDateFormat(format);
		Date time=null;
		try {
			
		   time= sdf.parse(sdf.format(new Date()));
		} catch (ParseException e) {

		   e.printStackTrace();
		}
		return time;
	}
	
	/**
	   * 将长时间格式时间转换为字符串 yyyy-MM-dd HH:mm:ss
	   * 
	   * @param dateDate
	   * @return
	   */
	public static String dateToStrLong(Date dateDate,String endCode) {
	   SimpleDateFormat formatter = new SimpleDateFormat(endCode);
	   String dateString = formatter.format(dateDate);
	   return dateString;
	}
	
	/**
	 * 获取当前时间字符串
	 * @param format 时间格式
	 * @return String
	 */
	public static String getStringDate(String format){
		
		SimpleDateFormat sdf=new SimpleDateFormat(format);
		return sdf.format(new Date());
	}
	
	public static void main(String[] args) {
//		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String string = DateUtil.dateToStrLong(DateUtil.getDate("yyyy-MM-ddHHmm:ss"),"yyyyMMdd");
		System.out.println(string);
	}
}
