package com.grep.util;

import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * 网关验签数据工具类 
 * @author jaysonQiu
 *
 */
public class SignUtil {

	private static final String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

	/**
	 * MD5加密
	 * @param data 字符串
	 * @param enCode 编码格式
	 * @return
	 */
    public static String encode(String data,String enCode) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] byteArray = md5.digest(data.getBytes(enCode));
            String passwordMD5 = byteArrayToHexString(byteArray);
            return passwordMD5.toUpperCase();
        } catch (Exception e) {
        }
        return data;
    }

    /**
     * 
     * @param map 数据
     * @param key 秘钥
     * @return sign 验签数据
     */
	public static String getSign(Map<String, Object> map, String key){
		String mString = arraysSortUtil(map);
		String data = encode(mString, "GBK");
		String sign = signUtil(data, key);
		System.out.println("密钥:"+key);
		System.out.println("排序:"+mString);
		System.out.println("MD5:"+data);
		System.out.println("签名:"+sign);
		return sign;
	}
	
	/**
	 * 排序工具
	 */
	public static String arraysSortUtil(Map<String, Object> map){
		
		StringBuffer sign = new StringBuffer();
		
		//移除秘钥
		map.remove("pay_sign");
		
		Object [] arr = map.keySet().toArray();
		Arrays.sort(arr);
		for (int i = arr.length - 1; i >= 0; i--) {
			
			sign.append(map.get(arr[i]));
		}
		return sign.toString();
	}
		
	public static String encode(String keyString) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
    		md5.update(keyString.getBytes("utf-8"));
            String result = "";
    		byte[] temp;
    		temp = md5.digest("".getBytes("utf-8"));
    		for (int i = 0; i < temp.length; i++) {
    			result += Integer.toHexString((0x000000ff & temp[i]) | 0xffffff00).substring(6);
    		}
    		return result.toUpperCase();
        } catch (Exception e) {
        	
        }
        return keyString;
    }
	
	/**
	 * 根据字符串进行加密
	 * @param data （值）
	 * @param key  （秘钥）
	 * @return
	 */
	public static String signUtil(String data, String key) {
		
		 byte[] byteHMAC = null;
	       try {
	           
	           SecretKeySpec spec = new SecretKeySpec(key.getBytes(), "HmacSHA1");
	           Mac mac = Mac.getInstance("HmacSHA1");
	           mac.init(spec);
	           byteHMAC = mac.doFinal(data.getBytes());
	       
	           return byte2hex(byteHMAC);
	       }catch(InvalidKeyException e){
	    	   
	    	   e.printStackTrace();
	       }catch(NoSuchAlgorithmException e){
				// TODO Auto-generated catch block
				e.printStackTrace();
	       }
	       return "";
    }
	
	//进行秘钥加密
	private static String byte2hex(byte[] b){
		
	     StringBuilder hs = new StringBuilder();
	     String stmp;
	     for (int n = 0; b!=null && n < b.length; n++) {
	         stmp = Integer.toHexString(b[n] & 0XFF);
	         if (stmp.length() == 1)
	             hs.append('0');
	         hs.append(stmp);
	     }
	     return hs.toString().toUpperCase();
	}  
	
	private static String byteArrayToHexString(byte[] byteArray) {
        StringBuffer sb = new StringBuffer();
        for (byte b : byteArray) {
            sb.append(byteToHexChar(b));
        }
        return sb.toString();
    }
	
	private static Object byteToHexChar(byte b) {
        int n = b;
        if (n < 0) {
            n = 256 + n;
        }
        int d1 = n / 16;
        int d2 = n % 16;
        return hex[d1] + hex[d2];
    }
}
