package com.grep.util.cashiersyn;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Map;

public class CashierSynUtil {
	
	
	/**
	 * 通过map参数生成sign字符串
	 * @param map 数据参数
	 * @param secret 约定的私钥
	 * @return
	 * @throws UnsupportedEncodingException 
	 * @throws NoSuchAlgorithmException 
	 */
	public static String sign(Map<String, Object> map,String secret) throws Exception{
		
		map.put("dog_sk", secret);
		//map.remove("sign");
		Object[] key = map.keySet().toArray();
		Arrays.sort(key);
		StringBuffer sb = new StringBuffer();
		for (int i = key.length - 1; i >= 0; i--) {
			sb.append(map.get(key[i]));
		}
		String keyString = sb.toString();
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		md5.update(keyString.getBytes("utf-8"));
		String result = "";
		byte[] temp;
		temp = md5.digest("".getBytes("utf-8"));
		for (int i = 0; i < temp.length; i++) {
			result += Integer.toHexString((0x000000ff & temp[i]) | 0xffffff00).substring(6);
		}
		return result.toUpperCase();
}
}
