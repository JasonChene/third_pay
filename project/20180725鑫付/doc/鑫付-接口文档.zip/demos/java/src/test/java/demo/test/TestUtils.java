/**
 * 
 */
package demo.test;

/**
 *
 */
public class TestUtils {

    public static String getPrivateKey() {
        StringBuffer sb = new StringBuffer();
        String slipt = "\n";
        // sb.append("-----BEGIN RSA PRIVATE KEY-----").append(slipt);
        sb.append("MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMWsB4hUn7Y/m0K2").append(slipt);
        sb.append("lWnpJXVOLsLd9YKWkaqieU4WN74RILqXVraMb0b1avtlYDF7A2mf1B+yu3XTvhsL").append(slipt);
        sb.append("+/4Zm0rcmvSgvzlcJzeMOCWpVgDI6sm/PkSXbZk1cwghg/y76CxXHO9qDNH1x8Lr").append(slipt);
        sb.append("gBnB1I3TbEm8KAj6htCZIsxdnck3AgMBAAECgYBHo/l253Sa0KKsow+zutPgl91K").append(slipt);
        sb.append("srbwBTH17byZGGRLdlmuRnse3fbWeMu1ISCjzjmGZm6yrkxSf9M+ajGB/jXRYN41").append(slipt);
        sb.append("RJestmvXWIyZ0RUeUIbSqNJPUcwn/Qew11APJo+Nk2aotlMb3LOB6hxhDW17jyxv").append(slipt);
        sb.append("EKbKQRktkAa3dMYTAQJBAOSlfyHB/hs9OvtXExXgap7oTmA5l/GIpKuOllGXWQ4Y").append(slipt);
        sb.append("Lcju9rUdImIJ1O3kgEmsajQJGXIHiQKlfGBHiBqCF5ECQQDdUelZ8hguSJlGQKt6").append(slipt);
        sb.append("CN09AoinTpEvNlTstXmrWwXnQHj2SvwaH1gl0A06wl3IXHd3+6b3M8hl3YyvoKPC").append(slipt);
        sb.append("1UBHAkEA1LL4D0lNv704LzQTdxhrVyQ4NN+e73vz4/wi7gfjOm9XuEJEkrtljtoi").append(slipt);
        sb.append("kKMujFqt+XY1i5Ri6mlTyKUCgdZfYQJARkXA6z9UcDW6/TSBfgEchkesrjrjHHOK").append(slipt);
        sb.append("6ZIBrOf86t1syv8qJv021uLFoJeggYLiqCUucaVuhvGevxEpji559wJAPRdTLogZ").append(slipt);
        sb.append("ZVRXMxnXqeFPHrdDL1pgEHqWaz4V6NRVP1vgnUcnADpgZCIpc5ahZNOxVqTE1n/d").append(slipt);
        sb.append("b0rFwqGnHa5Z0A==").append(slipt);
        // sb.append("-----END RSA PRIVATE KEY-----");

        return sb.toString();
    }

}
